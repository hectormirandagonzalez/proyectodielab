from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from pdf2image import convert_from_path
from pdf2image import convert_from_bytes
from io import BytesIO
#from reportlab.pdfbase import pdfmetrics
#from reportlab.pdfbase.pdfmetrics import registerFontFamily
#from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime

def procesa_jmp(cod_ensayo, encabezado, detalle_pdf, verpng):
    try:
        print(detalle_pdf)
        #pdfmetrics.registerFont(TTFont('Vera', 'Vera.ttf'))
        #pdfmetrics.registerFont(TTFont('VeraBd', 'VeraBd.ttf'))
        #pdfmetrics.registerFont(TTFont('VeraMoBd', 'VeraMoBd.ttf'))
        
        datos_ejemplo = detalle_pdf
        
        #print(datos_ejemplo)
        #datos_ejemplo = [['1', 'JMP-00345', 'NOVAX', 'NUEVO', '0', '12', 'APROBADO', '5,6', 'APROBADO', '#N/D', '#N/D', '#N/D', '#N/D', '--', 'RECHAZADO'], ['2', 'JMP-00346', 'NOVAX', 'NUEVO', '0', '12', 'APROBADO', '3,4', 'APROBADO', '#N/D', '#N/D', '#N/D', '#N/D', '--', 'RECHAZADO']]
        #datos_ejemplo = [['1', 'GNT-00345', 'NOVAX', '360', '0', '5', '--', 'Falla', '10,00', 'RECHAZADO']]
        
        archivo = BytesIO()

        #archivo = cod_ensayo + ".pdf"
        #archivo_png = cod_ensayo + ".png"
        if (cod_ensayo[0:7]=='LAT-MNG'):
            for tuplas in datos_ejemplo:
                #print('tuplas')
                #print(tuplas)
                del tuplas[9]
                del tuplas[3]
                #print('datos_mng')
                #print(tuplas)
                #datos_mng = datos_mng.pop(3)
                #print(datos_mng)
        hoy = datetime.now()
        w, h = A4
        c = canvas.Canvas(archivo)
        c.drawImage("logo_sm2.jpg", 20, h - 85, 82, 70)
        c.setFont("Helvetica-Bold", 11)
        c.drawString(250, h - 40, "INFORME DE ENSAYO")
        c.setFont("Helvetica", 8)
        c.drawString(260, h - 50, "QuintaEnergy Laboratorios.")
        c.drawString(210, h - 60, "Avenida Ventisquero 1265, bodega N°3, Renca, Santiago.")
        c.setFont("Helvetica-Bold", 11)
        #c.drawString(255, h - 80, "LAT   -   GNT   -   005") #1  cod ensayo
        c.drawString(270, h - 80, cod_ensayo) #1  cod ensayo

        print('linea 25')
        #############  cuadro de lugar ensayo y datos cliente
        offset_vertical = 20
        c.setFont("Helvetica-Bold", 8)
        c.drawString(10, h - 120 + offset_vertical, "LUGAR DEL ENSAYO Y CONDICIONES AMBIENTALES")
        c.drawString(300, h - 120 + offset_vertical, "ANTECEDENTES DEL CLIENTE")

        c.setLineWidth(1)
        c.line(10, h - 125 + offset_vertical, 290, h - 125 + offset_vertical)
        c.line(300, h - 125 + offset_vertical, 580, h -125 + offset_vertical)

        c.setFont("Helvetica", 8)
        c.drawString(10, h - 140 + offset_vertical, "Lugar")
        c.drawString(10, h - 170 + offset_vertical, "Fecha Ejecución")
        c.drawString(10, h - 185 + offset_vertical, "Realizó")
        c.drawString(10, h - 200 + offset_vertical, "Temperatura (°C) / Humedad (%)")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(145, h - 140 + offset_vertical, ":")
        c.drawString(145, h - 170 + offset_vertical, ":")
        c.drawString(145, h - 185 + offset_vertical, ":")
        c.drawString(145, h - 200 + offset_vertical, ":")

        c.setFont("Helvetica", 8)
        #c.drawString(150, h - 140 + offset_vertical, "Avenida Ventisquero 1265")
        #c.drawString(150, h - 155 + offset_vertical, "bodega N°3, Renca, Santiago.")

        c.drawString(150, h - 140 + offset_vertical, encabezado["dir1_esy"])
        c.drawString(150, h - 155 + offset_vertical, encabezado["dir2_esy"])

        c.drawString(150, h - 170 + offset_vertical, encabezado["fecha_ejecucion"])    #2 fecha ejecucion
        c.drawString(150, h - 185 + offset_vertical, encabezado["tecnico"])           #3 tecnico a cargo
        c.drawString(150, h - 200 + offset_vertical, encabezado["temperatura"] + "/" + encabezado["humedad"])   #4 T° #5 Humedad
        print('linea 54')
        c.drawString(300, h - 140 + offset_vertical, "Cliente")
        c.drawString(300, h - 155 + offset_vertical, "Dirección")
        c.drawString(300, h - 185 + offset_vertical, "Sucursal")
        c.drawString(300, h - 200 + offset_vertical, "Fecha Solicitud o Ingreso")
        c.drawString(300, h - 215 + offset_vertical, "Documento de Referencia")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(435, h - 140 + offset_vertical, ":")
        c.drawString(435, h - 155 + offset_vertical, ":")
        c.drawString(435, h - 185 + offset_vertical, ":")
        c.drawString(435, h - 200 + offset_vertical, ":")
        c.drawString(435, h - 215 + offset_vertical, ":")

        c.setFont("Helvetica", 8)
        c.drawString(440, h - 140 + offset_vertical, encabezado["cliente"])         #6 cliente
        c.drawString(440, h - 155 + offset_vertical, encabezado["dir1"]) #7 Dirección 1° parte
        c.drawString(440, h - 170 + offset_vertical, encabezado["dir2"])      #8 direccion 2° parte
        c.drawString(440, h - 185 + offset_vertical, encabezado["ciudad"])           #9 ciudad
        c.drawString(440, h - 200 + offset_vertical, encabezado["fecha_ingreso"])           #10 fecha ingreso solicitud
        c.drawString(440, h - 215 + offset_vertical, encabezado["orden_compra"])           #10 orden compra
        print('linea 72')
        salto = 120
        #######3 cuadro de patron y elementos
        c.setFont("Helvetica-Bold", 8)
        c.drawString(10, h - 120 - salto + offset_vertical, "CARACTERÍSTICAS DEL PATRÓN")
        c.drawString(300, h - 120 - salto + offset_vertical, "ELEMENTOS PROTECCIÓN PERSONAL")

        c.setLineWidth(1)
        c.line(10, h - 125 - salto + offset_vertical, 290, h - 125 - salto + offset_vertical)
        c.line(300, h - 125 - salto + offset_vertical, 580, h -125 - salto + offset_vertical)

        c.setFont("Helvetica", 8)
        c.drawString(10, h - 140 - salto + offset_vertical, "Descripción")
        c.drawString(10, h - 155 - salto + offset_vertical, "Marca")
        c.drawString(10, h - 170 - salto + offset_vertical, "Modelo")
        c.drawString(10, h - 185 - salto + offset_vertical, "N° Serie")
        c.drawString(10, h - 200 - salto + offset_vertical, "Calibración Vigente Hasta")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(145, h - 140 - salto + offset_vertical, ":")
        c.drawString(145, h - 155 - salto + offset_vertical, ":")
        c.drawString(145, h - 170 - salto + offset_vertical, ":")
        c.drawString(145, h - 185 - salto + offset_vertical, ":")
        c.drawString(145, h - 200 - salto + offset_vertical, ":")

        c.setFont("Helvetica", 8)
        c.drawString(150, h - 140 - salto + offset_vertical, encabezado["patron"])           #11 patron descrip
        c.drawString(150, h - 155 - salto + offset_vertical, encabezado["marca"])           #12 marca patron
        
        c.drawString(150, h - 170 - salto + offset_vertical, encabezado["modelo"])               #13 modelo
        c.drawString(150, h - 185 - salto + offset_vertical, encabezado["serie_patron"])  #14 serie patron
        c.drawString(150, h - 200 - salto + offset_vertical, encabezado["calibracion"])     #15 vigencia

        c.drawString(300, h - 140 - salto + offset_vertical, "Tipo de EPP")
        c.drawString(300, h - 155 - salto + offset_vertical, "Cantidad")
        #c.drawString(300, h - 170 - salto, "Cantidad")
        print('linea 108')
        c.setFont("Helvetica-Bold", 8)
        c.drawString(435, h - 140 - salto + offset_vertical, ":")
        c.drawString(435, h - 155 - salto + offset_vertical, ":")
        #c.drawString(435, h - 170 - salto, ":")

        c.setFont("Helvetica", 8)
        c.drawString(440, h - 140 - salto + offset_vertical, encabezado["tipo_epp"])      #16 tipo epp
        #c.drawString(440, h - 155 - salto, encabezado["uso"])        #17 usado - nuevo
        #c.drawString(440, h - 170 - salto, encabezado["piezas"] + " piezas")    #18 cantidad en informe
        c.drawString(440, h - 155 - salto + offset_vertical, encabezado["piezas"] + " piezas")

        #### tabla resultado
        salto = 190
        c.setFont("Helvetica-Bold", 8)
        c.drawString(260, h - 120 - salto, "TABLA DE RESULTADOS")
        c.setLineWidth(1)
        c.line(10, h - 125 - salto, 580, h - 125 - salto)

        print('linea 125')
        ### genera grilla
        if (cod_ensayo[0:7]=='LAT-GNT'):
            print('entra en LAT-GNT')
            xlist = [10, 35, 100, 150, 185, 230, 270, 330, 380, 435, 510, 580]
        elif (cod_ensayo[0:7]=='LAT-JMP'):
            print('entra en LAT-JMP')
            xlist1 = [10, 35, 100, 150, 210, 270, 340, 445, 520, 580]
            xlist2 = [10, 35, 100, 150, 210, 270, 340, 445, 580] 
        else:
            print('entra en ELSE')
            xlist = [10, 35, 100, 150, 185, 230, 270, 330, 380, 445, 520, 580]
        ylist = [h - 135 - salto, h - 165 - salto]
        #print(ylist)
        #primera tabla
        for i in range(1,7):
            ylist.append(h - 165 - salto - i*15)
        c.grid(xlist1, ylist)
        ### titulo ensayos dielectricos
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 135 - salto, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(265, h - 133.5 - salto, "ENSAYO DIELÉCTRICO")

        #segunda tabla
        altura = -140
        ylist = [h - 135 - salto + altura, h - 165 - salto + altura]
        for i in range(1,7):
            ylist.append(h - 165 - salto - i*15 + altura)
        c.grid(xlist2, ylist)
        ### titulo ensayos resistencia electrica
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 135 - salto + altura, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(240, h - 133.5 - salto + altura, "ENSAYO RESISTENCIA ELÉCTRICA")
        #print(ylist)

        ## llena grilla
        ### encabezado
        print('cod_ensayo[', cod_ensayo[0:7], ']')
        if (cod_ensayo[0:7]=='LAT-GNT'):
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(108, h - 150 - salto, "MARCA")         #3
            c.drawString(152, h - 150 - salto, "LARGO")         #4
            c.drawString(155, h - 160 - salto, "(mm)")
            c.drawString(190, h - 150 - salto, "ESTADO")        #5
            c.drawString(235, h - 150 - salto, "CLASE")         #6
            c.drawString(275, h - 150 - salto, "TENSIÓN DE")    #7
            c.drawString(275, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(335, h - 150 - salto, "NUM DE")        #8
            c.drawString(335, h - 160 - salto, "PARCHES")
            c.drawString(385, h - 150 - salto, "I FUGA (mA)")   #9
            c.drawString(440, h - 150 - salto, "I MÁX DE FUGA") #10
            c.drawString(440, h - 160 - salto, "PERMITIDA (mA)")
            c.drawString(515, h - 150 - salto, "RESULTADO")     #11
        else:
            ##primera tabla
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(108, h - 150 - salto, "MARCA")         #3
            c.drawString(160, h - 150 - salto, "ESTADO")        #4
            c.drawString(225, h - 150 - salto, "CLASE")         #5
            c.drawString(275, h - 150 - salto, "TENSIÓN DE")    #6
            c.drawString(275, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(370, h - 150 - salto, "INSPECCIÓN")    #6
            c.drawString(370, h - 160 - salto, "VISUAL")
            c.drawString(455, h - 150 - salto, "I FUGA (mA)")   #7
            c.drawString(525, h - 150 - salto, "RESULTADO")     #8

            ##segunda tabla
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto + altura, "ITEM")           #1
            c.drawString(40, h - 150 - salto + altura, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto + altura, "BAJO PRUEBA")
            c.drawString(108, h - 150 - salto + altura, "TRAMO")         #3
            c.drawString(155, h - 150 - salto + altura, "SECCIÓN")        #4
            c.drawString(155, h - 160 - salto + altura, "CONDUCTOR") 
            c.drawString(215, h - 150 - salto + altura, "LONGITUD")         #5
            c.drawString(232, h - 160 - salto + altura, "(ft)")
            c.drawString(275, h - 150 - salto + altura, "RESISTENCIA")    #6
            c.drawString(275, h - 160 - salto + altura, "MEDIDA (μΩ)")
            c.drawString(370, h - 150 - salto + altura, "RESITENCIA")    #6
            c.drawString(370, h - 160 - salto + altura, "MÁXIMA (μΩ)")
            c.drawString(490, h - 150 - salto + altura, "RESULTADO")     #8
        #### aquí va el llenado de la tabla
        c.setFont("Courier-Bold", 8)
        #c.drawString(10, h - 175 - salto, "--------")
        #c.drawString(55, h - 175 - salto, "GNT-00123")
        #c.drawString(140, h - 175 - salto, "SALSBURY")
        #c.drawString(195, h - 175 - salto, "360")
        #c.drawString(235, h - 175 - salto, "0")
        #c.drawString(275, h - 175 - salto, "5")
        #c.drawString(335, h - 175 - salto, "--")
        #c.drawString(385, h - 175 - salto, "FALLA")
        #c.drawString(440, h - 175 - salto, "10")
        #c.drawString(515, h - 175 - salto, "RECHAZADO")

        # de prueba
        #c.drawString(27.59, h - 190 - salto, "0")
        #c.drawString(63.27, h - 190 - salto, "GNT-00123")
        ################################################
        #margenes = []
        print('linea 171')

        
        #llena primera tabla
        saltar = 0
        for tuplas in datos_ejemplo:
            print('xlist: ', xlist1)
            print('Tupla: ', tuplas)
            tuplas1 = tuplas[0:9]
            tuplas2 = tuplas[0:2] + tuplas[9:15]
            print(tuplas2)
            i = 0
            for valor in xlist1:
                margen = 0
                if (i == 0):
                    i = i +1
                else:
                    margen = (xlist1[i] - xlist1[i-1] - len(tuplas1[i-1])*4.8278)/2 + xlist1[i-1]
                    c.drawString(margen, h - 175 - saltar - salto, tuplas1[i-1])
                    #margenes.append(margen)
                    #print(margen)
                    i = i + 1
            saltar = saltar + 15

        #llena segunda tabla
        salto = 330
        saltar = 0
        for tuplas in datos_ejemplo:
            print('xlist: ', xlist2)
            print('Tupla: ', tuplas)
            tuplas1 = tuplas[0:2] + tuplas[9:15]
            i = 0
            for valor in xlist2:
                margen = 0
                if (i == 0):
                    i = i +1
                else:
                    margen = (xlist2[i] - xlist2[i-1] - len(tuplas1[i-1])*4.8278)/2 + xlist2[i-1]
                    c.drawString(margen, h - 175 - saltar - salto, tuplas1[i-1])
                    #margenes.append(margen)
                    #print(margen)
                    i = i + 1
            saltar = saltar + 15

        ### cuadro conclusiones
        c.rect(10, h - 630, 570, 30)
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 600, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(275, h - 599, "CONCLUSIÓN")
        print('linea 193')
        c.setFont("Helvetica", 8)
        c.drawString(15, h - 610, "Según los resultados obtenenidos en los ensayos dieléctricos, las unidades bajo prueba individualizados que aparecen como aprobados en la tabla anterior,")
        c.drawString(15, h - 620, "cumplen con lo indicado en las Normas ASTM D120-14, ASTM F1236-96 y ASTM F496-08.")

        ### observaciones
        c.rect(10, h - 710, 570, 60)
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 650, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(230, h - 648, "OBSERVACIONES Y/O ALCANCES")
        c.setFont("Helvetica", 7)
        c.drawString(15, h - 657, "Los equipos patrones utilizados para estos ensayos cuentan con su certificado de calibración y/o verificación vigente y trazable al sistema internacional de unidades (SI).")
        c.drawString(15, h - 667, "Los resultados expuestos corresponden únicamente al ítem identificado bajo prueba y sólo bajo las condiciones mencionadas.")
        c.drawString(15, h - 677, "Este informe sólo puede ser difundido íntegro y sin modificaciones ni enmiendas.")
        c.drawString(15, h - 687, "Este informe de ensayo no podrá ser reproducido parcialmente sin la aprobación por escrito de QuintaEnergy, el cual declina toda responsabilidad por el uso indebido de")
        c.drawString(15, h - 697, "este documento.")
        c.drawString(15, h - 707, "Este informe es válido con firma y timbre.")
        print('linea 212')
        c.drawImage("firma_v.jpg", 80, h - 785, 102, 56)
        c.drawImage("timbre_v.jpg", 420, h - 775, 61, 62)
        c.setLineWidth(0.5)
        c.line(70, h - 780, 200, h - 780)
        c.line(380, h - 780, 510, h -780)
        print('linea 218')
        c.setFont("Helvetica", 8)
        c.drawString(100, h - 790, "José Cortez Lazcano")
        c.drawString(90, h - 800, "Responsable Laboratorios")

        c.drawString(410, h - 790, "Timbre de Laboratorio")
        print('linea 224')
        c.drawString(100, h - 820, "Fecha Emisión")
        print('linea 226')
        c.drawString(105, h - 830, encabezado["fecha_emision"])          #19 fecha emision
        print('linea 228')
        c.drawString(420, h - 820, "Fecha Impresión")
        print('linea 230')
        #c.drawString(425, h - 830,hoy.strftime('%d-%m-%Y'))          #20 fecha impresion
        c.drawString(425, h - 830, encabezado["fecha_impresion"])          #20 fecha impresion
        print('linea 233')
        c.drawString(285, h - 830, "Página 1 de 1")
        print('linea 235')
        c.showPage()
        print('linea 237')
        c.save()
        #esto es para el bytes.io
        archivo.seek(0)
        #########################
        print('linea 239')
        """
        if (verpng):
            archivo_png = BytesIO()
            pages = convert_from_path(archivo, 80, fmt="png")
            for page in pages:
                #page.save(cod_ensayo + '.jpg', 'JPEG')
                page.save(archivo_png, 'PNG')
            archivo_png.seek(0)
        """
        archivo_png = BytesIO()
        if (verpng):
            pages = convert_from_bytes(archivo.read(), 80, fmt="png")
            for page in pages:
                #page.save(cod_ensayo + '.jpg', 'JPEG')
                page.save(archivo_png, 'PNG')
            archivo_png.seek(0)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        print('ERROR', str(e))
        return resultado
    if verpng:
        #resultado = {"error":False, "msg": archivo_png}
        #return resultado
        return archivo_png
    else:
        #resultado = {"error":False, "msg": archivo}
        #return resultado
        return archivo