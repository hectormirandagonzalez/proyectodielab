from multiprocessing.dummy import Array
from openpyxl import Workbook
from openpyxl.styles import Font

def procesa_stat_xls(tabla_xls, nom_archivo):
    #print('tabla_:', tabla_xls)
    print('nom_archivo: ', nom_archivo)
    try:
        wb = Workbook()
        ws = wb.active
        ws['A1'] = 'Elemento'
        ws['B1'] = 'Unidades Ensayadas'
        ws['C1'] = 'Unidades Aprobadas'
        ws['D1'] = 'Unidades Rechazadas'
        ws['E1'] = 'Tasa Falla (%)'
        ws['A1'].font = Font(bold=True)
        ws['B1'].font = Font(bold=True)
        ws['C1'].font = Font(bold=True)
        ws['D1'].font = Font(bold=True)
        ws['E1'].font = Font(bold=True)
        for linea in tabla_xls:
            print('linea_xls: ', linea)
            #ws.append([linea.nombre, linea.total, linea.aprobado, linea.rechazado, linea.tasa_falla])
            ws.append([linea['nombre'], linea['total'], linea['aprobado'], linea['rechazado'], linea['tasa_falla']])
        wb.save(nom_archivo + '.xlsx')
        resultado = {"error":False, "msg": nom_archivo + '.xlsx'}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        print('ERROR', str(e))
        return resultado
    return resultado

def procesa_historial_xls(tabla_xls, nom_archivo):
    #print('tabla_:', tabla_xls)
    print('nom_archivo: ', nom_archivo)
    try:
        wb = Workbook()
        ws = wb.active
        ws['A1'] = 'Empresa'
        ws['B1'] = 'Elemento'
        ws['C1'] = 'Marca'
        ws['D1'] = 'Clase'
        ws['E1'] = 'Fecha Ensayo'
        ws['F1'] = 'Informe Ensayo Emitido'
        ws['G1'] = 'Unidad Bajo Prueba'
        ws['H1'] = 'Días por Vencer'
        ws['A1'].font = Font(bold=True)
        ws['B1'].font = Font(bold=True)
        ws['C1'].font = Font(bold=True)
        ws['D1'].font = Font(bold=True)
        ws['E1'].font = Font(bold=True)
        ws['F1'].font = Font(bold=True)
        ws['G1'].font = Font(bold=True)
        ws['H1'].font = Font(bold=True)
        for linea in tabla_xls:
            print('linea_xls: ', linea)
            #ws.append([linea.nombre, linea.total, linea.aprobado, linea.rechazado, linea.tasa_falla])
            ws.append([linea['empresa'], linea['elemento'], linea['marca'], \
                linea['clase'], linea['fecha_ensayo'], linea['informe_ensayo'], \
                    linea['epp_ensayado'], linea['dias_venci']])
        wb.save(nom_archivo + '.xlsx')
        resultado = {"error":False, "msg": nom_archivo + '.xlsx'}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        print('ERROR', str(e))
        return resultado
    return resultado