from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from pdf2image import convert_from_path
from io import BytesIO
#from reportlab.pdfbase import pdfmetrics
#from reportlab.pdfbase.pdfmetrics import registerFontFamily
#from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime

def procesa_lodbus(cod_ensayo, encabezado, detalle_pdf, verpng):
    try:
        print(detalle_pdf)
        datos_ejemplo = detalle_pdf[0]

        archivo = BytesIO()

        #archivo = cod_ensayo + ".pdf"
        #archivo_png = cod_ensayo + ".png"

        hoy = datetime.now()
        w, h = A4
        c = canvas.Canvas(archivo)
        c.drawImage("logo_sm2.jpg", 20, h - 85, 82, 70)
        c.setFont("Helvetica-Bold", 11)
        c.drawString(250, h - 40, "INFORME DE ENSAYO")
        c.setFont("Helvetica", 8)
        c.drawString(260, h - 50, "QuintaEnergy Laboratorios.")
        c.drawString(210, h - 60, "Avenida Ventisquero 1265, bodega N°3, Renca, Santiago.")
        c.setFont("Helvetica-Bold", 11)
        #c.drawString(255, h - 80, "LAT   -   GNT   -   005") #1  cod ensayo
        c.drawString(270, h - 80, cod_ensayo) #1  cod ensayo

        print('linea 25')
        #############  cuadro de lugar ensayo y datos cliente
        c.setFont("Helvetica-Bold", 8)
        offset1 = -100
        c.drawString(10, h - 20 + offset1, "ANTECEDENTES DEL CLIENTE")
        c.drawString(300, h - 20 + offset1, "CARACTERÍSTICAS DEL PATRÓN")
        c.line(300, h - 25 + offset1, 590, h - 25 + offset1)

        c.setFont("Helvetica", 8)
        #c.setLineWidth(1)
        c.line(10, h - 25 + offset1, 290, h - 25 + offset1)
        #c.line(10, h - 125, 580, h -125)
        c.drawString(10, h - 40 + offset1, "Cliente")
        c.drawString(10, h - 50 + offset1, "Dirección")
        c.drawString(10, h - 70 + offset1, "Ciudad")
        c.drawString(10, h - 80 + offset1, "Fecha Solicitud o Ingreso")
        c.drawString(10, h - 90 + offset1, "Documento de Referencia")

        c.setFont("Helvetica", 8)
        c.drawString(140, h - 40 + offset1, encabezado["cliente"])         #6 cliente
        c.drawString(140, h - 50 + offset1, encabezado["dir1"]) #7 Dirección 1° parte
        c.drawString(140, h - 60 + offset1, encabezado["dir2"])      #8 direccion 2° parte
        c.drawString(140, h - 70 + offset1, encabezado["ciudad"])           #9 ciudad
        c.drawString(140, h - 80 + offset1, encabezado["fecha_ingreso"])           #10 fecha ingreso solicitud
        c.drawString(140, h - 90 + offset1, encabezado["orden_compra"])           #10 orden compra

        c.line(10, h - 95 + offset1, 290, h - 95 + offset1)

        ####c.line(300, h - 30 + offset1, 590, h - 30 + offset1)
        #c.line(10, h - 125, 580, h -125)
        c.drawString(300, h - 45 + offset1, "Descripción")
        c.drawString(300, h - 55 + offset1, "Marca")
        c.drawString(300, h - 65 + offset1, "Modelo")
        c.drawString(300, h - 75 + offset1, "N° Serie")
        c.drawString(300, h - 85 + offset1, "Calibración vigente hasta")

        c.drawString(430, h - 45 + offset1, datos_ejemplo[13])
        c.drawString(430, h - 55 + offset1, datos_ejemplo[14])
        c.drawString(430, h - 65 + offset1, datos_ejemplo[15])
        c.drawString(430, h - 75 + offset1, datos_ejemplo[16])
        c.drawString(430, h - 85 + offset1, datos_ejemplo[17])

        c.line(300, h - 95 + offset1, 590, h - 95 + offset1)
        
        offset1 = -185
        c.setFont("Helvetica-Bold", 8)
        c.drawString(10, h - 25 + offset1, "UNIDAD BAJO ENSAYO")
        #c.drawString(300, h - 25 + offset1, "LUGAR DEL ENSAYO Y CONDICIONES AMBIENTALES")

        c.setFont("Helvetica", 8)
        #c.setLineWidth(1)
        c.line(10, h - 30 + offset1, 290, h - 30 + offset1)
        #c.line(10, h - 125, 580, h -125)
        c.drawString(10, h - 45 + offset1, "Elemento")
        c.drawString(10, h - 55 + offset1, "Marca")
        c.drawString(10, h - 65 + offset1, "N° Serie")
        c.drawString(10, h - 75 + offset1, "Código")
        c.drawString(10, h - 85 + offset1, "Estado")

        c.drawString(140, h - 45 + offset1, "LoadBuster")
        c.drawString(140, h - 55 + offset1, datos_ejemplo[2])   #MArca
        c.drawString(140, h - 65 + offset1, datos_ejemplo[12])  #serie fabrica
        c.drawString(140, h - 75 + offset1, datos_ejemplo[1])   #codigo epp
        c.drawString(140, h - 85 + offset1, datos_ejemplo[4])   #nuevo usado

        c.line(10, h - 95 + offset1, 290, h - 95 + offset1)

        c.setFont("Helvetica", 8)
        #c.setLineWidth(1)
        c.line(300, h - 30 + offset1, 590, h - 30 + offset1)
        c.drawString(300, h - 45 + offset1, "Descripción")
        c.drawString(300, h - 55 + offset1, "Marca")
        c.drawString(300, h - 65 + offset1, "Modelo")
        c.drawString(300, h - 75 + offset1, "N° Serie")
        c.drawString(300, h - 85 + offset1, "Calibración vigente hasta")

        c.drawString(430, h - 45 + offset1, datos_ejemplo[18])
        c.drawString(430, h - 55 + offset1, datos_ejemplo[19])
        c.drawString(430, h - 65 + offset1, datos_ejemplo[20])
        c.drawString(430, h - 75 + offset1, datos_ejemplo[21])
        c.drawString(430, h - 85 + offset1, datos_ejemplo[22])

        c.line(300, h - 95 + offset1, 590, h - 95 + offset1)

        offset1 = -270
        c.setFont("Helvetica-Bold", 8)
        c.drawString(10, h - 25 + offset1, "LUGAR DEL ENSAYO Y CONDICION DE ENSAYO")
        #c.drawString(300, h - 25 + offset1, "LUGAR DEL ENSAYO Y CONDICIONES AMBIENTALES")

        c.setFont("Helvetica", 8)
        #c.setLineWidth(1)
        c.line(10, h - 30 + offset1, 290, h - 30 + offset1)
        #c.line(10, h - 125, 580, h -125)
        c.drawString(10, h - 45 + offset1, "Lugar")
        c.drawString(10, h - 65 + offset1, "Fecha Ejecución")
        c.drawString(10, h - 75 + offset1, "Realizó")
        c.drawString(10, h - 85 + offset1, "Temperatura (°C) / Humedad (%)")

        c.setFont("Helvetica", 8)
        c.drawString(140, h - 45 + offset1, "Avenida Ventisquero 1265")
        c.drawString(140, h - 55 + offset1, "bodega N°3, Renca, Santiago.")
        c.drawString(140, h - 65 + offset1, encabezado["fecha_ejecucion"])    #2 fecha ejecucion
        c.drawString(140, h - 75 + offset1, encabezado["tecnico"])           #3 tecnico a cargo
        c.drawString(140, h - 85 + offset1, encabezado["temperatura"] + "/" + encabezado["humedad"])
        c.line(10, h - 95 + offset1, 290, h - 95 + offset1)

        c.setFont("Helvetica", 8)
        #c.setLineWidth(1)
        c.line(300, h - 30 + offset1, 590, h - 30 + offset1)
        c.drawString(300, h - 45 + offset1, "Descripción")
        c.drawString(300, h - 55 + offset1, "Marca")
        c.drawString(300, h - 65 + offset1, "Modelo")
        c.drawString(300, h - 75 + offset1, "N° Serie")
        c.drawString(300, h - 85 + offset1, "Calibración vigente hasta")

        c.drawString(430, h - 45 + offset1, datos_ejemplo[23])
        c.drawString(430, h - 55 + offset1, datos_ejemplo[24])
        c.drawString(430, h - 65 + offset1, datos_ejemplo[25])
        c.drawString(430, h - 75 + offset1, datos_ejemplo[26])
        c.drawString(430, h - 85 + offset1, datos_ejemplo[27])

        c.line(300, h - 95 + offset1, 590, h - 95 + offset1)

        #### tabla resultado
        salto = 230
        offset = -130
        c.setFont("Helvetica-Bold", 8)
        c.drawString(260, h - 20 + offset - salto, "TABLA DE RESULTADOS")
        c.setLineWidth(1)
        c.line(10, h - 25 - salto + offset, 580, h - 25 + offset - salto)
        
        #Tabla de resultados
        #lineas horizontales
        c.line(10, (h - 40 - salto) + offset, 580, (h - 40 - salto) + offset)
        c.line(10, (h - 55 - salto) + offset, 580, (h - 55 - salto) + offset)
        c.line(180, (h - 70 - salto) + offset, 520, (h - 70 - salto) + offset)
        c.line(10, (h - 85 - salto) + offset, 520, (h - 85 - salto) + offset)
        c.line(10, (h - 100 - salto) + offset, 580, (h - 100 - salto) + offset)
        c.line(10, (h - 115 - salto) + offset, 580, (h - 115 - salto) + offset)
        #lineas verticales
        c.line(10, (h - 40 - salto) + offset, 10, (h - 115 - salto) + offset)
        c.line(580, (h - 40 - salto) + offset, 580, (h - 115 - salto) + offset)
        c.line(180, (h - 55 - salto) + offset, 180, (h - 115 - salto) + offset)
        c.line(520, (h - 55 - salto) + offset, 520, (h - 115 - salto) + offset)
        c.line(105, (h - 85 - salto) + offset, 105, (h - 115 - salto) + offset)
        c.line(155, (h - 85 - salto) + offset, 155, (h - 115 - salto) + offset)
        c.line(350, (h - 70 - salto) + offset, 350, (h - 115 - salto) + offset)
        c.line(275, (h - 85 - salto) + offset, 275, (h - 115 - salto) + offset)
        c.line(325, (h - 85 - salto) + offset, 325, (h - 115 - salto) + offset)
        c.line(445, (h - 85 - salto) + offset, 445, (h - 115 - salto) + offset)
        c.line(495, (h - 85 - salto) + offset, 495, (h - 115 - salto) + offset)
        c.drawString(290, h - 52 + offset - salto, "ENSAYOS")
        c.drawString(300, h - 68 + offset - salto, "RESISTENCIA ELÉCTRICA")
        c.drawString(200, h - 82 + offset - salto, "AISLACION (C. ABIERTO)")
        c.drawString(370, h - 82 + offset - salto, "CONTACTO (C. CERRADO)")
        c.drawString(50, h - 75 + offset - salto, "DIELÉCTRICO")
        c.drawString(525, h - 85 + offset - salto, "RESULTADO")


        offsetHor = 0
        c.setFont("Helvetica-Bold", 8)
        c.drawString(15 + offsetHor, h - 97 + offset - salto, "TENSIÓN DE ENSAYO")
        c.drawString(115 + offsetHor, h - 97 + offset - salto, "I FUGA")
        c.drawString(158 + offsetHor, h - 97 + offset - salto, "A - R")
        offsetHor = 170
        c.setFont("Helvetica-Bold", 8)
        c.drawString(15 + offsetHor, h - 97 + offset - salto, "TENSIÓN DE ENSAYO")
        c.drawString(115 + offsetHor, h - 97 + offset - salto, "MEDIDA")
        c.drawString(158 + offsetHor, h - 97 + offset - salto, "A - R")
        offsetHor = 340
        c.setFont("Helvetica-Bold", 8)
        c.drawString(15 + offsetHor, h - 97 + offset - salto, "TENSIÓN DE ENSAYO")
        c.drawString(115 + offsetHor, h - 97 + offset - salto, "MEDIDA")
        c.drawString(158 + offsetHor, h - 97 + offset - salto, "A - R")

        c.setFont("Courier-Bold", 8)
        xlist = [10, 105, 155, 180, 275, 325, 350, 445, 495, 520, 580]
        tuplas = datos_ejemplo[28:38] ## traspasa los datos de laparte ensayo
        print('tuplas: ', tuplas)
        #tuplas = ["27 (kV)", "37,0 (mA)", "A", "27 (kV)", "37,0 (mA)", "A", "27 (kV)", "37,0 (mA)", "A", "APROBADO"]
        i = 0
        for valor in xlist:
            margen = 0
            if (i == 0):
                i = i +1
            else:
                margen = (xlist[i] - xlist[i-1] - len(tuplas[i-1])*4.8278)/2 + xlist[i-1]
                c.drawString(margen,h - 110 + offset - salto, tuplas[i-1])
                i = i + 1

        offset = -120
        #horizontales segund tabla
        c.line(10, (h - 130 - salto) + offset, 580, (h - 130 - salto) + offset)
        c.line(10, (h - 145 - salto) + offset, 580, (h - 145 - salto) + offset)
        c.line(10, (h - 160 - salto) + offset, 580, (h - 160 - salto) + offset)
        c.line(10, (h - 175 - salto) + offset, 580, (h - 175 - salto) + offset)
        c.line(10, (h - 190 - salto) + offset, 580, (h - 190 - salto) + offset)
        c.line(10, (h - 205 - salto) + offset, 580, (h - 205 - salto) + offset)

        #lineas verticales
        #linea de costados
        c.line(10, (h - 130 - salto) + offset, 10, (h - 205 - salto) + offset)
        c.line(580, (h - 130 - salto) + offset, 580, (h - 205 - salto) + offset)
        #lineas del medio
        c.line(200, (h - 145 - salto) + offset, 200, (h - 205 - salto) + offset)
        c.line(390, (h - 145 - salto) + offset, 390, (h - 205 - salto) + offset)
        c.setFont("Courier-Bold", 8)
        #inspecciones = ["A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "0045"]
        inspecciones = datos_ejemplo[38:49]
        c.drawString(15, h - 155 + offset - salto, "CARCAZA                         : " + inspecciones[0])
        c.drawString(15, h - 170 + offset - salto, "CONJUNTO GANCHO SUJECIÓN        : " + inspecciones[1])
        c.drawString(15, h - 185 + offset - salto, "CONJUNTO ANCLA                  : " + inspecciones[2])
        c.drawString(15, h - 200 + offset - salto, "CONTADOR DE OPERACIONES         : " + inspecciones[3])

        c.drawString(205, h - 155 + offset - salto, "APERTURA ANILLO DE TIRO        : " + inspecciones[4])
        c.drawString(205, h - 170 + offset - salto, "CIERRE ANILLO DE TIRO          : " + inspecciones[5])
        c.drawString(205, h - 185 + offset - salto, "EXTENSION DE TIRO              : " + inspecciones[6])
        c.drawString(205, h - 200 + offset - salto, "CIERRE DE TIRO                 : " + inspecciones[7])

        c.drawString(395, h - 155 + offset - salto, "SEGURO DE RESTABLECIMIENTO     : " + inspecciones[8])
        c.drawString(395, h - 170 + offset - salto, "CUBIERTA                       : " + inspecciones[9])
        c.drawString(395, h - 185 + offset - salto, "CONTADOR                       : " + inspecciones[10])
        c.drawString(395, h - 200 + offset - salto, "-------------------------------------")

        c.drawString(15, h - 215 + offset - salto,"*Nota: A=Aprobado, R=Rechazado.")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(260, (h - 140 - salto) + offset, "INSPECCIÓN VISUAL")
        ### cuadro conclusiones
        c.rect(10, h - 630, 570, 50)
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 580, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(275, h - 578, "CONCLUSIÓN")
        print('linea 193')

        conclusiones = [datos_ejemplo[37], datos_ejemplo[48], datos_ejemplo[10]]
        c.setFont("Courier-Bold", 8)
        c.drawString(15, h - 595, "ENSAYOS                   : " + conclusiones[0])
        c.drawString(15, h - 610, "INSPECCIÓN VISUAL         : " + conclusiones[0])
        c.drawString(15, h - 625, "RESULTADO                 : " + conclusiones[0])

        ### observaciones
        c.rect(10, h - 710, 570, 60)
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 650, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(230, h - 648, "OBSERVACIONES Y/O ALCANCES")
        c.setFont("Helvetica", 7)
        c.drawString(15, h - 657, "Los equipos patrones utilizados para estos ensayos cuentan con su certificado de calibración y/o verificación vigente y trazable al sistema internacional de unidades (SI).")
        c.drawString(15, h - 667, "Los resultados expuestos corresponden únicamente al ítem identificado bajo prueba y sólo bajo las condiciones mencionadas.")
        c.drawString(15, h - 677, "Este informe sólo puede ser difundido íntegro y sin modificaciones ni enmiendas.")
        c.drawString(15, h - 687, "Este informe de ensayo no podrá ser reproducido parcialmente sin la aprobación por escrito de QuintaEnergy, el cual declina toda responsabilidad por el uso indebido de")
        c.drawString(15, h - 697, "este documento.")
        c.drawString(15, h - 707, "Este informe es válido con firma y timbre.")
        print('linea 212')
        c.drawImage("firma_v.jpg", 80, h - 785, 102, 56)
        c.drawImage("timbre_v.jpg", 420, h - 775, 61, 62)
        c.setLineWidth(0.5)
        c.line(70, h - 780, 200, h - 780)
        c.line(380, h - 780, 510, h -780)
        print('linea 218')
        c.setFont("Helvetica", 8)
        c.drawString(100, h - 790, "José Cortez Lazcano")
        c.drawString(90, h - 800, "Responsable Laboratorios")

        c.drawString(410, h - 790, "Timbre de Laboratorio")
        print('linea 224')
        c.drawString(100, h - 820, "Fecha Emisión")
        print('linea 226')
        c.drawString(105, h - 830, encabezado["fecha_emision"])          #19 fecha emision
        print('linea 228')
        c.drawString(420, h - 820, "Fecha Impresión")
        print('linea 230')
        #c.drawString(425, h - 830,hoy.strftime('%d-%m-%Y'))          #20 fecha impresion
        c.drawString(425, h - 830, encabezado["fecha_impresion"])          #20 fecha impresion
        print('linea 233')
        c.drawString(285, h - 830, "Página 1 de 1")
        print('linea 235')
        c.showPage()
        print('linea 237')
        c.save()
        #esto es para el bytes.io
        archivo.seek(0)
        #########################
        print('linea 239')
        if (verpng):
            archivo_png = BytesIO()
            pages = convert_from_path(archivo, 80, fmt="png")
            for page in pages:
                #page.save(cod_ensayo + '.jpg', 'JPEG')
                page.save(archivo_png, 'PNG')
            archivo_png.seek(0)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        print('ERROR', str(e))
        return resultado
    if verpng:
        #resultado = {"error":False, "msg": archivo_png}
        #return resultado
        return archivo_png
    else:
        #resultado = {"error":False, "msg": archivo}
        #return resultado
        return archivo