from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
#from reportlab.pdfbase import pdfmetrics
#from reportlab.pdfbase.pdfmetrics import registerFontFamily
#from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime

def procesa(cod_ensayo, encabezado, detalle_pdf):
    try:
        print(detalle_pdf)
        #pdfmetrics.registerFont(TTFont('Vera', 'Vera.ttf'))
        #pdfmetrics.registerFont(TTFont('VeraBd', 'VeraBd.ttf'))
        #pdfmetrics.registerFont(TTFont('VeraMoBd', 'VeraMoBd.ttf'))
        datos_ejemplo = detalle_pdf
        #print(datos_ejemplo)
        #datos_ejemplo = [['1', 'GNT-00345', 'NOVAX', '360', '0', '5', '--', 'Falla', '10,00', 'RECHAZADO'], ['2', 'GNT-00346', 'NOVAX', '360', '0', '5', '--', 'Falla', '10,00', 'APROBADO']]
        #datos_ejemplo = [['1', 'GNT-00345', 'NOVAX', '360', '0', '5', '--', 'Falla', '10,00', 'RECHAZADO']]
        archivo = cod_ensayo + ".pdf"
        if (cod_ensayo[0:7]=='LAT-MNG'):
            for tuplas in datos_ejemplo:
                #print('tuplas')
                #print(tuplas)
                del tuplas[9]
                del tuplas[3]
                #print('datos_mng')
                #print(tuplas)
                #datos_mng = datos_mng.pop(3)
                #print(datos_mng)
        if (cod_ensayo[0:7]=='LAT-MNT'):
            for tuplas in datos_ejemplo:
                #print('tuplas')
                #print(tuplas)
                del tuplas[9]
                del tuplas[7]
                #print('datos_mng')
                #print(tuplas)
                #datos_mng = datos_mng.pop(3)
                #print(datos_mng)
        if (cod_ensayo[0:7]=='LAT-ATR'):
            for tuplas in datos_ejemplo:
                #print('tuplas')
                #print(tuplas)
                del tuplas[9]
                del tuplas[7]
                del tuplas[5]
                #print('datos_mng')
                #print(tuplas)
                #datos_mng = datos_mng.pop(3)
                #print(datos_mng)
        if (cod_ensayo[0:7]=='LAT-PRT'):
            for tuplas in datos_ejemplo:
                #print('tuplas')
                #print(tuplas)
                del tuplas[9]
                del tuplas[7]
                del tuplas[5]
                #print('datos_mng')
                #print(tuplas)
                #datos_mng = datos_mng.pop(3)
                #print(datos_mng)
        hoy = datetime.now()
        w, h = A4
        c = canvas.Canvas(archivo)
        c.drawImage("logo_sm2.jpg", 20, h - 85, 82, 70)
        c.setFont("Helvetica-Bold", 11)
        c.drawString(250, h - 40, "INFORME DE ENSAYO")
        c.setFont("Helvetica", 8)
        c.drawString(260, h - 50, "QuintaEnergy Laboratorios.")
        c.drawString(210, h - 60, "Avenida Ventisquero 1265, bodega N°4, Renca, Santiago.")
        c.setFont("Helvetica-Bold", 11)
        #c.drawString(255, h - 80, "LAT   -   GNT   -   005") #1  cod ensayo
        c.drawString(270, h - 80, cod_ensayo) #1  cod ensayo

        print('linea 25')
        #############  cuadro de lugar ensayo y datos cliente
        c.setFont("Helvetica-Bold", 8)
        c.drawString(10, h - 120, "LUGAR DEL ENSAYO Y CONDICIONES AMBIENTALES")
        c.drawString(300, h - 120, "ANTECEDENTES DEL CLIENTE")

        c.setLineWidth(1)
        c.line(10, h - 125, 290, h - 125)
        c.line(300, h - 125, 580, h -125)

        c.setFont("Helvetica", 8)
        c.drawString(10, h - 140, "Lugar")
        c.drawString(10, h - 170, "Fecha Ejecución")
        c.drawString(10, h - 185, "Realizó")
        c.drawString(10, h - 200, "Temperatura (°C) / Humedad (%)")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(145, h - 140, ":")
        c.drawString(145, h - 170, ":")
        c.drawString(145, h - 185, ":")
        c.drawString(145, h - 200, ":")

        c.setFont("Helvetica", 8)
        c.drawString(150, h - 140, "Avenida Ventisquero 1265")
        c.drawString(150, h - 155, "bodega N°4, Renca, Santiago.")

        c.drawString(150, h - 170, encabezado["fecha_ejecucion"])    #2 fecha ejecucion
        c.drawString(150, h - 185, encabezado["tecnico"])           #3 tecnico a cargo
        c.drawString(150, h - 200, encabezado["temperatura"] + "/" + encabezado["humedad"])   #4 T° #5 Humedad
        print('linea 54')
        c.drawString(300, h - 140, "Cliente")
        c.drawString(300, h - 155, "Dirección")
        c.drawString(300, h - 185, "Ciudad")
        c.drawString(300, h - 200, "Fecha Solicitud o Ingreso")
        c.drawString(300, h - 215, "Documento de Referencia")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(435, h - 140, ":")
        c.drawString(435, h - 155, ":")
        c.drawString(435, h - 185, ":")
        c.drawString(435, h - 200, ":")
        c.drawString(435, h - 215, ":")

        c.setFont("Helvetica", 8)
        c.drawString(440, h - 140, encabezado["cliente"])         #6 cliente
        c.drawString(440, h - 155, encabezado["dir1"]) #7 Dirección 1° parte
        c.drawString(440, h - 170, encabezado["dir2"])      #8 direccion 2° parte
        c.drawString(440, h - 185, encabezado["ciudad"])           #9 ciudad
        c.drawString(440, h - 200, encabezado["fecha_ingreso"])           #10 fecha ingreso solicitud
        c.drawString(440, h - 215, encabezado["orden_compra"])           #10 orden compra
        print('linea 72')
        salto = 120
        #######3 cuadro de patron y elementos
        c.setFont("Helvetica-Bold", 8)
        c.drawString(10, h - 120 - salto, "CARACTERÍSTICAS DEL PATRÓN")
        c.drawString(300, h - 120 - salto, "ELEMENTOS PROTECCIÓN PERSONAL")

        c.setLineWidth(1)
        c.line(10, h - 125 - salto, 290, h - 125 - salto)
        c.line(300, h - 125 - salto, 580, h -125 - salto)

        c.setFont("Helvetica", 8)
        c.drawString(10, h - 140 - salto, "Descripción")
        c.drawString(10, h - 155 - salto, "Marca")
        c.drawString(10, h - 170 - salto, "Modelo")
        c.drawString(10, h - 185 - salto, "N° Serie")
        c.drawString(10, h - 200 - salto, "Calibración Vigente Hasta")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(145, h - 140 - salto, ":")
        c.drawString(145, h - 155 - salto, ":")
        c.drawString(145, h - 170 - salto, ":")
        c.drawString(145, h - 185 - salto, ":")
        c.drawString(145, h - 200 - salto, ":")

        c.setFont("Helvetica", 8)
        c.drawString(150, h - 140 - salto, encabezado["patron"])           #11 patron descrip
        c.drawString(150, h - 155 - salto, encabezado["marca"])           #12 marca patron
        
        c.drawString(150, h - 170 - salto, encabezado["modelo"])               #13 modelo
        c.drawString(150, h - 185 - salto, encabezado["serie_patron"])  #14 serie patron
        c.drawString(150, h - 200 - salto, encabezado["calibracion"])     #15 vigencia

        c.drawString(300, h - 140 - salto, "Tipo de EPP")
        c.drawString(300, h - 155 - salto, "Cantidad")
        #c.drawString(300, h - 170 - salto, "Cantidad")
        print('linea 108')
        c.setFont("Helvetica-Bold", 8)
        c.drawString(435, h - 140 - salto, ":")
        c.drawString(435, h - 155 - salto, ":")
        #c.drawString(435, h - 170 - salto, ":")

        c.setFont("Helvetica", 8)
        c.drawString(440, h - 140 - salto, encabezado["tipo_epp"])      #16 tipo epp
        #c.drawString(440, h - 155 - salto, encabezado["uso"])        #17 usado - nuevo
        #c.drawString(440, h - 170 - salto, encabezado["piezas"] + " piezas")    #18 cantidad en informe
        c.drawString(440, h - 155 - salto, encabezado["piezas"] + " piezas")

        #### tabla resultado
        salto = 230
        c.setFont("Helvetica-Bold", 8)
        c.drawString(260, h - 120 - salto, "TABLA DE RESULTADOS")
        c.setLineWidth(1)
        c.line(10, h - 125 - salto, 580, h - 125 - salto)
        print('linea 125')
        ### genera grilla
        if (cod_ensayo[0:7]=='LAT-GNT'):
            print('entra en LAT-GNT')
            xlist = [10, 35, 100, 150, 185, 230, 270, 330, 380, 435, 510, 580]
        elif (cod_ensayo[0:7]=='LAT-MNG'):
            print('entra en LAT-MGN')
            xlist = [10, 35, 100, 185, 230, 270, 330, 380, 435, 580]
        elif (cod_ensayo[0:7]=='LAT-MNT'):
            print('entra en LAT-MNT')
            xlist = [10, 35, 100, 185, 230, 270, 330, 380, 435, 580]
        elif (cod_ensayo[0:7]=='LAT-ATR'):
            print('entra en LAT-ATR')
            xlist = [10, 35, 100, 165, 230, 290, 380, 510, 580]
        elif (cod_ensayo[0:7]=='LAT-PRT'):
            print('entra en LAT-PRT')
            xlist = [10, 35, 100, 165, 230, 290, 380, 510, 580]
            #         
        else:
            print('entra en ELSE')
            xlist = [10, 35, 100, 150, 185, 230, 270, 330, 380, 435, 510, 580]
        ylist = [h - 135 - salto, h - 165 - salto]
        #print(ylist)
        for i in range(1,13):
            ylist.append(h - 165 - salto - i*15)
        c.grid(xlist, ylist)
        #print(ylist)

        ## llena grilla
        ### encabezado
        print('cod_ensayo[', cod_ensayo[0:7], ']')
        if (cod_ensayo[0:7]=='LAT-GNT'):
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(108, h - 150 - salto, "MARCA")         #3
            c.drawString(152, h - 150 - salto, "LARGO")         #4
            c.drawString(155, h - 160 - salto, "(mm)")
            c.drawString(190, h - 150 - salto, "ESTADO")        #5
            c.drawString(235, h - 150 - salto, "CLASE")         #6
            c.drawString(275, h - 150 - salto, "TENSIÓN DE")    #7
            c.drawString(275, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(335, h - 150 - salto, "NUM DE")        #8
            c.drawString(335, h - 160 - salto, "PARCHES")
            c.drawString(385, h - 150 - salto, "I FUGA (mA)")   #9
            c.drawString(440, h - 150 - salto, "I MÁX DE FUGA") #10
            c.drawString(440, h - 160 - salto, "PERMITIDA (mA)")
            c.drawString(515, h - 150 - salto, "RESULTADO")     #11
        elif (cod_ensayo[0:7]=='LAT-MNG'):
            ####
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(128, h - 150 - salto, "MARCA")         #3
            c.drawString(190, h - 150 - salto, "ESTADO")        #4
            c.drawString(235, h - 150 - salto, "CLASE")         #5
            c.drawString(275, h - 150 - salto, "TENSIÓN DE")    #6
            c.drawString(275, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(335, h - 150 - salto, "NUM DE")        #7
            c.drawString(335, h - 160 - salto, "PARCHES")
            c.drawString(385, h - 150 - salto, "I FUGA (mA)")   #8
            c.drawString(482, h - 150 - salto, "RESULTADO")     #9
        elif (cod_ensayo[0:7]=='LAT-MNT'):
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(108, h - 150 - salto, "MARCA")         #3
            c.drawString(190, h - 150 - salto, "TIPO")          #4
            c.drawString(235, h - 150 - salto, "ESTADO")        #5
            c.drawString(275, h - 150 - salto, "CLASE")         #6
            c.drawString(335, h - 150 - salto, "TENSIÓN DE")    #7
            c.drawString(335, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(385, h - 150 - salto, "I FUGA (mA)")   #8
            c.drawString(515, h - 150 - salto, "RESULTADO")     #9
        elif (cod_ensayo[0:7]=='LAT-ATR'):
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(118, h - 150 - salto, "MARCA")         #3
            c.drawString(170, h - 150 - salto, "N° CUERPOS")        #4
            c.drawString(242, h - 150 - salto, "ESTADO")         #5
            c.drawString(305, h - 150 - salto, "TENSIÓN DE")    #6
            c.drawString(305, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(415, h - 150 - salto, "I FUGA (mA)")   #7
            c.drawString(520, h - 150 - salto, "RESULTADO")     #8
        elif (cod_ensayo[0:7]=='LAT-PRT'):
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(118, h - 150 - salto, "MARCA")         #3
            c.drawString(170, h - 150 - salto, "N° CUERPOS")        #4
            c.drawString(242, h - 150 - salto, "ESTADO")         #5
            c.drawString(305, h - 150 - salto, "TENSIÓN DE")    #6
            c.drawString(305, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(415, h - 150 - salto, "I FUGA (mA)")   #7
            c.drawString(520, h - 150 - salto, "RESULTADO")     #8
        else:
            c.setFont("Helvetica-Bold", 8)
            c.drawString(12, h - 150 - salto, "ITEM")           #1
            c.drawString(40, h - 150 - salto, "Nº UNIDAD")      #2
            c.drawString(38, h - 160 - salto, "BAJO PRUEBA")
            c.drawString(108, h - 150 - salto, "MARCA")         #3
            c.drawString(152, h - 150 - salto, "LARGO")         #4
            c.drawString(155, h - 160 - salto, "(mm)")
            c.drawString(190, h - 150 - salto, "ESTADO")        #5
            c.drawString(235, h - 150 - salto, "CLASE")         #6
            c.drawString(275, h - 150 - salto, "TENSIÓN DE")    #7
            c.drawString(275, h - 160 - salto, "ENSAYO (KV)")
            c.drawString(335, h - 150 - salto, "NUM DE")        #8
            c.drawString(335, h - 160 - salto, "PARCHES")
            c.drawString(385, h - 150 - salto, "I FUGA (mA)")   #9
            c.drawString(440, h - 150 - salto, "I MÁX DE FUGA") #10
            c.drawString(440, h - 160 - salto, "PERMITIDA (mA)")
            c.drawString(515, h - 150 - salto, "RESULTADO")     #11
        #### aquí va el llenado de la tabla
        c.setFont("Courier-Bold", 8)
        #c.drawString(10, h - 175 - salto, "--------")
        #c.drawString(55, h - 175 - salto, "GNT-00123")
        #c.drawString(140, h - 175 - salto, "SALSBURY")
        #c.drawString(195, h - 175 - salto, "360")
        #c.drawString(235, h - 175 - salto, "0")
        #c.drawString(275, h - 175 - salto, "5")
        #c.drawString(335, h - 175 - salto, "--")
        #c.drawString(385, h - 175 - salto, "FALLA")
        #c.drawString(440, h - 175 - salto, "10")
        #c.drawString(515, h - 175 - salto, "RECHAZADO")

        # de prueba
        #c.drawString(27.59, h - 190 - salto, "0")
        #c.drawString(63.27, h - 190 - salto, "GNT-00123")
        ################################################
        #margenes = []
        print('linea 171')
        saltar = 0
        for tuplas in datos_ejemplo:
            print('xlist: ', xlist)
            print('Tupla: ', tuplas)
            i = 0
            for valor in xlist:
                margen = 0
                if (i == 0):
                    i = i +1
                else:
                    margen = (xlist[i] - xlist[i-1] - len(tuplas[i-1])*4.8278)/2 + xlist[i-1]
                    c.drawString(margen, h - 175 - saltar - salto, tuplas[i-1])
                    #margenes.append(margen)
                    #print(margen)
                    i = i + 1
            saltar = saltar + 15
        ### cuadro conclusiones
        c.rect(10, h - 630, 570, 30)
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 600, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(275, h - 599, "CONCLUSIÓN")
        print('linea 193')
        c.setFont("Helvetica", 8)
        c.drawString(15, h - 610, "Según los resultados obtenenidos en los ensayos dieléctricos, las unidades bajo prueba individualizados que aparecen como aprobados en la tabla anterior,")
        c.drawString(15, h - 620, "cumplen con lo indicado en las Normas ASTM D120-14, ASTM F1236-96 y ASTM F496-08.")

        ### observaciones
        c.rect(10, h - 710, 570, 60)
        c.setFillColorRGB(0.84, 0.86, 0.87)
        c.rect(10, h - 650, 570, 10, fill=True)
        c.setFillColorRGB(0, 0, 0)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(230, h - 648, "OBSERVACIONES Y/O ALCANCES")
        c.setFont("Helvetica", 7)
        c.drawString(15, h - 657, "Los equipos patrones utilizados para estos ensayos cuentan con su certificado de calibración y/o verificación vigente y trazable al sistema internacional de unidades (SI).")
        c.drawString(15, h - 667, "Los resultados expuestos corresponden únicamente al ítem identificado bajo prueba y solo bajo las condiciones mencionadas.")
        c.drawString(15, h - 677, "Este informe sólo puede ser difundido íntegro y sin modificaciones ni enmiendas.")
        c.drawString(15, h - 687, "Este informe de ensayo no podrá ser reproducido parcialmente sin la aprobación por escrito de QuintaEnergy, el cual declina toda responsabilidad por el uso indebido de")
        c.drawString(15, h - 697, "este documento.")
        c.drawString(15, h - 707, "Este informe es válido con firma y timbre.")
        print('linea 212')
        c.drawImage("firma.jpg", 70, h - 775, 102, 56)
        c.drawImage("timbre.jpg", 420, h - 775, 61, 62)
        c.setLineWidth(0.5)
        c.line(70, h - 780, 200, h - 780)
        c.line(380, h - 780, 510, h -780)
        print('linea 218')
        c.setFont("Helvetica", 8)
        c.drawString(100, h - 790, "José Cortez Lazcano")
        c.drawString(90, h - 800, "Responsable Laboratorios")

        c.drawString(410, h - 790, "Timbre de Laboratorio")
        print('linea 224')
        c.drawString(100, h - 820, "Fecha Emisión")
        print('linea 226')
        c.drawString(105, h - 830, encabezado["fecha_emision"])          #19 fecha emision
        print('linea 228')
        c.drawString(420, h - 820, "Fecha Impresión")
        print('linea 230')
        #c.drawString(425, h - 830,hoy.strftime('%d-%m-%Y'))          #20 fecha impresion
        c.drawString(425, h - 830, encabezado["fecha_impresion"])          #20 fecha impresion
        print('linea 233')
        c.drawString(285, h - 830, "Página 1 de 1")
        print('linea 235')
        c.showPage()
        print('linea 237')
        c.save()
        print('linea 239')
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        print('ERROR', str(e))
        return resultado
    resultado = {"error":False, "msg": archivo}
    return resultado