from pdf2image import convert_from_path, convert_from_bytes

images = convert_from_path('LAT-GNT-00159.pdf', 80, fmt="png")
for image in images:
    image.save('ffff' + '.png', 'PNG')