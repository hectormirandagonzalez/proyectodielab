#Configuracón base de datos
dbase = {}
##dbase['HOST'] = 'localhost'
dbase['HOST'] = '129.151.117.171'
dbase['PORT'] = '5432'
##dbase['DATABASE'] = 'nuevaback'
dbase['DATABASE'] = 'backends3'
dbase['USER'] = 'postgres'
dbase['PASSWORD'] = 'cocacola123!!'

conexion = "postgresql+psycopg2://" + dbase['USER'] + ":" + dbase['PASSWORD'] + \
        "@" + dbase['HOST'] + ":" + dbase['PORT'] + "/" + dbase['DATABASE']