#Configuracón base de datos
dbase = {}
dbase['HOST'] = 'localhost'
dbase['PORT'] = '5432'
dbase['DATABASE'] = 'backends5'
dbase['USER'] = 'postgres'
dbase['PASSWORD'] = 'cocacola123!!'

conexion = "postgresql+psycopg2://" + dbase['USER'] + ":" + dbase['PASSWORD'] + \
        "@" + dbase['HOST'] + ":" + dbase['PORT'] + "/" + dbase['DATABASE']