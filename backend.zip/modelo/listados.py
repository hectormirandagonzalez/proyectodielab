from warnings import catch_warnings
from sqlalchemy import create_engine, MetaData, select, Table, and_, text
from modelo.config import conexion


def cliente():
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_cliente;")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id_cliente=row[0], nombre=row[1], direccion=row[2]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def ensayos(tipo_ensayo, serie_ensayo):
    #print('tipo_ensayo')
    #print(tipo_ensayo)
    #print('serie_ensayo')
    #print(serie_ensayo)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    if (serie_ensayo == None or serie_ensayo == ''):
        s = text("select * from dielab.lista_ensayos where tipo_ensayo = :a;")
        #print(s)
    else:
        if serie_ensayo[0:3] == 'LAT':
            s = text("select * from dielab.lista_ensayos where tipo_ensayo = :a and codigo = :b;")
        else:
            s = text("select * from dielab.lista_ensayos_x_epp where serie_epp = :a;")
        #print(s)
    try:
        if (serie_ensayo == None or serie_ensayo == ''):
            cur = engine2.connect().execute(s, {"a": tipo_ensayo})
        else:
            if serie_ensayo[0:3] == 'LAT':
                cur = engine2.connect().execute(s, {"a": tipo_ensayo, "b":serie_ensayo})
            else:
                 cur = engine2.connect().execute(s, {"a": serie_ensayo})
        salida = [dict(id=row[0], codigo=row[1], fecha_ingreso=row[2], cliente=row[3], negocio=row[4], estado=row[5]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def cod_ensayo(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_cod_ensayo(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def select_param(param):
    #print('entra en def select param: ' + param)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select * from dielab.select_" + param + ";")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id=row[0], nombre=row[1]) for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def form_ensayo(id_batea):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_form_ensayo where id_batea = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": id_batea})
        salida = [dict(id=row[0], cliente=row[1], negocio=row[2], \
             sucursal=row[3], temperatura=row[4], humedad=row[5], \
             tecnico=row[6], patron=row[7], fecha_ejecucion=row[8], \
             fecha_ingreso=row[9], cod_estado=row[10], orden_compra=row[11], dir_ensayo=row[12]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def check_epp(epp, cliente, negocio, sucursal):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.verifica_epp_guante(:a, :b, :c, :d);")
    try:
        cur = engine2.connect().execute(s, {"a": epp, "b": cliente, "c":sucursal, "d": negocio})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def check_epp_ldb(epp, cliente, negocio, sucursal):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.verifica_epp_ldb(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def epps(clase_epp, cod_epp):
    #print("valor clase epp:")
    #print(clase_epp)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    if (cod_epp == None or cod_epp == ''):
        s = text("select * from dielab.lista_epps where clase_epp = :a;")
    else:
        #s = text("select * from dielab.lista_epps where clase_epp = :a and num_serie = :b;")
        s = text("select * from dielab.lista_epps where clase_epp = :a and num_serie like :b;")
        print('consulta: ', s)
    try:
        if (cod_epp == None):
            cur = engine2.connect().execute(s, {"a": clase_epp})
        else:
            cur = engine2.connect().execute(s, {"a": clase_epp, "b": '%' + cod_epp + '%'})
        salida = [dict(id=row[0], num_serie=row[1], cliente=row[2], negocio=row[3], sucursal=row[4], estado=row[5]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
        print(resultado)
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def getcod_epp(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_cod_epp(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_detalle(id_batea, cod_epp):
    print('id_batea: ', id_batea)
    print('cod_epp: ', cod_epp)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    if (cod_epp=='JMP'):
        s = text("select * from dielab.lista_det_jumper where id_batea = :a;")
    else:
        s = text("select * from dielab.lista_det_guante where id_batea = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": id_batea})
        if (cod_epp=='JMP'):
            salida = [dict(serie_epp=row[2], fuga1=row[3], \
             tension=row[4], visual=row[5], dieresul=row[6], \
                tramo=row[7], seccion=row[8], longitud=row[9], \
                    resismedida=row[10], resismax=row[11], \
                        resisresul=row[12]) for row in cur.fetchall()]
        else:
            salida = [dict(serie=row[2], fuga1=row[3], fuga2=row[4], \
             fuga3=row[5], parches=row[6], promedio=row[7], \
             tension=row[8], resultado=row[9]) for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
        print(resultado)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_emision(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.obtiene_emision(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_encabezado_pdf(cod_ensayo):
    print('cod_ensayo: ', cod_ensayo)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_informe_pdf where cod_ensayo = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(cod_ensayo=row[0], fecha_ejecucion=row[1], tecnico=row[2], \
             temperatura=row[3], humedad=row[4], cliente=row[5], \
             dir1=row[6], dir2=row[7], ciudad=row[8], \
             fecha_ingreso=row[9], patron=row[10], marca=row[11], \
             modelo=row[12], serie_patron=row[13], calibracion=row[14], \
             tipo_epp=row[15], uso=row[16], piezas=row[17], \
             fecha_emision=row[18], fecha_impresion=row[19], orden_compra=row[20], dir1_esy=row[21], dir2_esy=row[22]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida[0]}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        print(str(e))
    return resultado

def get_encabezado_cliente(valorensayo, valorelemento, email):
    
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from clientes.get_encabezado_informe(:a, :b, :c) as (cod_ensayo varchar, \
         fecha_ejecucion text, tecnico varchar,temperatura text, humedad text, \
        cliente text, dir1 text, dir2 text, ciudad text, fecha_ingreso text, patron text, \
        marca varchar, modelo varchar, serie_patron varchar, calibracion varchar, \
        tipo_epp text, uso text, piezas text,fecha_emision text, fecha_impresion text, \
        orden_compra text, dir1_esy text, dir2_esy text);")
    try:
        cur = engine2.connect().execute(s, {"a": valorensayo, "b": valorelemento, "c": email})
        salida = [dict(cod_ensayo=row[0], fecha_ejecucion=row[1], tecnico=row[2], \
             temperatura=row[3], humedad=row[4], cliente=row[5], \
             dir1=row[6], dir2=row[7], ciudad=row[8], \
             fecha_ingreso=row[9], patron=row[10], marca=row[11], \
             modelo=row[12], serie_patron=row[13], calibracion=row[14], \
             tipo_epp=row[15], uso=row[16], piezas=row[17], \
             fecha_emision=row[18], fecha_impresion=row[19], orden_compra=row[20], dir1_esy=row[21], dir2_esy=row[22]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        print('salida', salida)
        if (salida == []):
            resultado = {"error": True, "msg": "No hay resultados para la búsqueda"}
        else:
            resultado = {"error": False, "datos": salida[0]}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_detalle_pdf(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    if cod_ensayo[4:7] == 'MNT':
        s = text("select * from dielab.get_detalle_pdf_mnt('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'GNT':
        s = text("select * from dielab.get_detalle_pdf_gnt('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'MNG':
        s = text("select * from dielab.get_detalle_pdf_mng('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'ATR':
        s = text("select * from dielab.get_detalle_pdf_atr('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'PRT':
        s = text("select * from dielab.get_detalle_pdf_prt('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, modelo text, usado text, cod_clase varchar, tension text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'CBL':
        s = text("select * from dielab.get_detalle_pdf_cbl('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'BNQ':
        s = text("select * from dielab.get_detalle_pdf_bnq('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    elif cod_ensayo[4:7] == 'LDB':
        s = text("select * from dielab.lista_detpdf_ldb where cod_ensayo = '" + str(cod_ensayo) + "';")
    elif cod_ensayo[4:7] == 'JMP':
        s = text("select * from dielab.get_detalle_pdf_jmp('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, usado text, cod_clase varchar, tension text, visual text, i_fuga text, dieresul text, tramo text, seccion text, longitud text, resismedida text, resismax text, resisresult text);")
    else:
        s = text("select * from dielab.get_detalle_pdf('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    try:
        cur = engine2.connect().execute(s)
        if cod_ensayo[4:7] == 'LDB':
            salida = [[row[0], row[1], row[2], row[3],row[4], row[5],row[6],row[7], \
                row[8],row[9],row[10], row[11], row[12], row[13], row[14], row[15], \
                row[16], row[17], row[18], row[19], row[20], row[21], row[22], row[23], \
                row[24], row[25], row[26], row[27], row[28], row[29], row[30], row[31], \
                row[32], row[33], row[34], row[35], row[36], row[37], row[38], row[39], \
                row[40], row[41], row[42], row[43], row[44], row[45], row[46], row[47], row[48], row[49]] for row in cur.fetchall()]
        elif cod_ensayo[4:7] == 'JMP':
            salida = [[row[0], row[1], row[2], row[3],row[4], row[5],row[6],row[7], \
                row[8],row[9],row[10], row[11], row[12], row[13], row[14]] for row in cur.fetchall()]
        else:
            salida = [[row[0], row[1], row[2], row[3],row[4], row[5],row[6],row[7],row[8],row[9],row[10]] for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def clase_epps():
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.select_clase_epp;")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id=row[0], nombre=row[1], cod_serie=row[2], tabla_detalle=row[3], nombre_menu=row[4]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
        #print(resultado)
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def clase_ensayo():
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.select_clase_ensayo;")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id=row[0], nombre=row[1], cod_informe=row[2], cod_serie=row[3], tabla_detalle=row[4], nombre_menu=row[5]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
        #print(resultado)
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_tabla_epp(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_tabla_x_epp(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        #print(salida)
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_tabla_pornombre(nombre_tabla):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_tabla_x_nombre(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": nombre_tabla})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        #print(salida)
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def form_in_epps(id_epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_form_epps where id_epp = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": id_epp})
        salida = [dict(id=row[0], cod_epp=row[1], tipo_epp=row[2], \
             cliente=row[3], negocio=row[4], sucursal=row[5], \
             periodicidad=row[6], estado_uso=row[7], estado_epp=row[8], serie_fabrica=row[9], epp_informe=row[10]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_tabla_x_nombreId(tabla_tipo, id_parametro):
    print('tabla_tipo: ', tabla_tipo, 'id_parametro: ', id_parametro)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.get_edit_param(:a, :b);")
    try:
        cur = engine2.connect().execute(s, {"a": tabla_tipo, "b": id_parametro})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado'] #{datos: {json}}
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_estadistica(fecha_ini, fecha_fin, usuario):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    if (fecha_ini == None or fecha_fin == None):
        resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
        return resultado
    else:
        if (fecha_ini == ''):
            resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
            return resultado
        elif (fecha_ini == ''):
            resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
            return resultado
        else:
            s = text("select * from clientes.get_resumen_ensayos(:a, :b, :c) as (nombre text, aprobado text, rechazado text, total text, tasa_falla text)")
    try:
        cur = engine2.connect().execute(s, {"a": fecha_ini, "b": fecha_fin, "c": usuario})
        salida = [dict(nombre=row[0], aprobado=row[1], rechazado=row[2], total=row[3], tasa_falla=row[4]) for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_epp_ensayados(fecha_ini, fecha_fin, cliente, tipo_epp, usuario):
    print('fecha_ini: ', fecha_ini, 'fecha_fin: ', fecha_fin, 'cliente: ', cliente, 'tipo_epp: ', \
        tipo_epp, 'usuario: ', usuario)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    if (fecha_ini == None or fecha_fin == None):
        resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
        return resultado
    else:
        if (fecha_ini == ''):
            resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
            return resultado
        elif (fecha_ini == ''):
            resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
            return resultado
        else:
            s = text("select * from clientes.get_elementos_ensayados(:a, :b, :c, :d, :e) as (empresa text, elemento text, marca text, clase text, fecha_ensayo text, informe_ensayo text, epp_ensayado text, dias text)")
    try:
        cur = engine2.connect().execute(s, {"a": fecha_ini, "b": fecha_fin, "c": cliente , "d": tipo_epp, "e": usuario})
        salida = [dict(empresa=row[0], elemento=row[1], marca=row[2], clase=row[3], \
            fecha_ensayo=row[4], informe_ensayo=row[5], epp_ensayado=row[6], dias_venci=row[7]) for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_informes_emitidos(fecha_ini, fecha_fin, cliente, tipo_epp, usuario):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    if (fecha_ini == None or fecha_fin == None):
        resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
        return resultado
    else:
        if (fecha_ini == ''):
            resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
            return resultado
        elif (fecha_ini == ''):
            resultado = {"error":True, "msg": "Debe especificar las fechas para buscar"}
            return resultado
        else:
            s = text("select * from clientes.get_consulta_masiva(:a, :b, :c, :d, :e) as (nombre_elemento text,elemento text,fecha_ensayo text,codigo text,cod_elemento text,cliente text )")
    try:
        print('1', fecha_ini, '2', fecha_fin, '3', cliente, '4', tipo_epp, '5', usuario)
        cur = engine2.connect().execute(s, {"a": fecha_ini, "b": fecha_fin, "c": cliente , "d": tipo_epp, "e": usuario})
        salida = [dict(empresa=row[0], elemento=row[1], fecha_ensayo=row[2], \
            informe_ensayo=row[3]) for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def busca_ensayo(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.busca_un_ensayo(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado