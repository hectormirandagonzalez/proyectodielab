from warnings import catch_warnings
from sqlalchemy import create_engine, MetaData, select, Table, and_, text
from modelo.config import conexion


def cliente():
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_cliente;")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id_cliente=row[0], nombre=row[1], direccion=row[2]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def ensayos(tipo_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_ensayos where tipo_ensayo = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": tipo_ensayo})
        salida = [dict(id=row[0], codigo=row[1], fecha_ingreso=row[2], cliente=row[3], negocio=row[4], estado=row[5]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def cod_ensayo(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_cod_ensayo(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def select_param(param):
    #print('entra en def select param: ' + param)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select * from dielab.select_" + param + ";")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id=row[0], nombre=row[1]) for row in cur.fetchall()]
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def form_ensayo(id_batea):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_form_ensayo where id_batea = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": id_batea})
        salida = [dict(id=row[0], cliente=row[1], negocio=row[2], \
             sucursal=row[3], temperatura=row[4], humedad=row[5], \
             tecnico=row[6], patron=row[7], fecha_ejecucion=row[8], \
             fecha_ingreso=row[9], cod_estado=row[10], orden_compra=row[11]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def check_epp(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.verifica_epp_guante(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def epps(clase_epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_epps where clase_epp = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": clase_epp})
        salida = [dict(id=row[0], num_serie=row[1], cliente=row[2], negocio=row[3], sucursal=row[4], estado=row[5]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
        #print(resultado)
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def getcod_epp(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_cod_epp(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_detalle(id_batea):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_det_guante where id_batea = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": id_batea})
        salida = [dict(serie=row[2], fuga1=row[3], fuga2=row[4], \
             fuga3=row[5], parches=row[6], promedio=row[7], \
             tension=row[8], resultado=row[9]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_emision(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.obtiene_emision(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_encabezado_pdf(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.lista_informe_pdf where cod_ensayo = :a;")
    try:
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(cod_ensayo=row[0], fecha_ejecucion=row[1], tecnico=row[2], \
             temperatura=row[3], humedad=row[4], cliente=row[5], \
             dir1=row[6], dir2=row[7], ciudad=row[8], \
             fecha_ingreso=row[9], patron=row[10], marca=row[11], \
             modelo=row[12], serie_patron=row[13], calibracion=row[14], \
             tipo_epp=row[15], uso=row[16], piezas=row[17], \
             fecha_emision=row[18], fecha_impresion=row[19]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida[0]}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_detalle_pdf(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.get_detalle_pdf('" + str(cod_ensayo) + "') as (id_num text, num_serie text, marca varchar, largo text, usado text, cod_clase varchar, tension text, parches text, i_fuga text, fuga_max text, resultado text);")
    try:
        cur = engine2.connect().execute(s)
        salida = [[row[0], row[1], row[2], row[3],row[4], row[5],row[6],row[7],row[8],row[9],row[10]] for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
        resultado = {"error": False, "datos": salida}
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def clase_epps():
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.select_clase_epp;")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id=row[0], nombre=row[1], cod_serie=row[2], tabla_detalle=row[3], nombre_menu=row[4]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
        #print(resultado)
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def clase_ensayo():
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    s = text("select * from dielab.select_clase_ensayo;")
    try:
        cur = engine2.connect().execute(s)
        salida = [dict(id=row[0], nombre=row[1], cod_informe=row[2], cod_serie=row[3], tabla_detalle=row[4], nombre_menu=row[5]) for row in cur.fetchall()]
        #salida.insert(0, {"error": False, "msg": ""})
        resultado = {"error": False, "datos": salida}
        #print(resultado)
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_tabla_epp(epp):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_tabla_x_epp(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": epp})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        print(salida)
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def get_tabla_pornombre(nombre_tabla):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    s = text("select dielab.genera_tabla_x_nombre(:a);")
    try:
        cur = engine2.connect().execute(s, {"a": nombre_tabla})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        print(salida)
        resultado = salida[0]['resultado']
        #salida.insert(0, {"error": False, "msg": ""})
        #print(salida)
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado