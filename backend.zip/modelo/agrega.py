import json
from warnings import catch_warnings
from sqlalchemy import create_engine, MetaData, select, Table, and_, text
from modelo.config import conexion


def addcliente(nombre,nombre_corto,responsable,fono,direccion):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    try:
        s = text("select dielab.ingresa_cliente(:a,:b,:c,:d,:e)")
        cur = engine2.connect().execute(s, {"a":nombre, "b": nombre_corto, "c": responsable, "d": fono, "e": direccion})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def addensayo(cod_ensayo,cliente,sucursal,negocio,temperature,humedad,tecnico,patron,fecha_ej,fecha_in, estado, tipo_ensayo, orden_compra):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.ingresa_enc_ensayo(:a, :b, :c, :d, :e, :f, :g, :h, :i, :l, :m, :n, :p);")
        #print(s)
        #print('graba ensayo:')
        #print(humedad)
        #print('valor de humedad')
        cur = engine2.connect().execute(s, {"a": cod_ensayo, "b":cliente, "c": sucursal, "d": negocio, "e": temperature, "f": humedad, "g": tecnico, "h": patron, "i": fecha_ej, "l": fecha_in, "m": estado, "n":tipo_ensayo, "p":orden_compra})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def adddetensayo(id_batea,detalle):
    #print('detalle: ', detalle)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.ingresa_detalle(:a, :b);")
        #print(s)
        cur = engine2.connect().execute(s, {"a": id_batea, "b":detalle})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def addepp(cod_epp, tipo, cliente,sucursal,negocio, estado, tipo_epp, periodicidad, estado_uso, serie_fabrica):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        if (tipo_epp == 'LDB'):
            #print('serie_fabrica:',serie_fabrica)
            s = text("select dielab.ingresa_epp_ldb(:a, :b, :c, :d, :e, :f, :g, :h, :i, :j)")
        else:
            #print('serie_fabrica:',serie_fabrica)
            s = text("select dielab.ingresa_epp(:a, :b, :c, :d, :e, :f, :g, :h, :i)")
        print('valor de s: ',cod_epp, tipo, cliente,sucursal,negocio, estado, tipo_epp, periodicidad, estado_uso, serie_fabrica)
        if (tipo_epp == 'LDB'):
            cur = engine2.connect().execute(s, {"a": cod_epp, "b": tipo, "c":cliente, "d": sucursal, "e": negocio, "f": estado, "g": tipo_epp, "h":periodicidad, "i":estado_uso, "j":serie_fabrica})
        else:
            cur = engine2.connect().execute(s, {"a": cod_epp, "b": tipo, "c":cliente, "d": sucursal, "e": negocio, "f": estado, "g": tipo_epp, "h":periodicidad, "i":estado_uso})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def emitecert(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.emite_certificado(:a);")
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def add_tipoepp(tipo_tabla,detalle):
    #print('tipo_tabla: ')
    #print(tipo_tabla)
    #print('detalle')
    #print(detalle)
    print('add', tipo_tabla,detalle)
    #print("a", detalle['nombre_usuario'], "b",detalle['nombre_persona'], "c",detalle['rut'], "d",detalle['email'], "e",detalle['telefono'], "f",detalle['password'], "g",detalle['cliente'])
    datos_json = json.loads(detalle)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        if (tipo_tabla == 'usuario'):
            s = text("select dielab.ingresa_usuario(:a, :b, :c, :d, :e, :f, :g);")
            #print("a", detalle['nombre_usuario'], "b",detalle['nombre_persona'], "c",detalle['rut'], "d",detalle['email'], "e",detalle['telefono'], "f",detalle['password'], "g",detalle['cliente'])
            cur = engine2.connect().execute(s, {"a": datos_json['nombre_usuario'], "b":datos_json['nombre_persona'], "c":datos_json['rut'], "d":datos_json['email'], "e":datos_json['telefono'], "f":datos_json['password'], "g":datos_json['cliente']})
            salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        else:
            s = text("select dielab.ingresa_det_tipo_epp(:a, :b);")
            cur = engine2.connect().execute(s, {"a": tipo_tabla, "b":detalle})
            salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def update_tipoepp(tipo_tabla,detalle, id_parametro):
    #print('tipo_tabla: ', tipo_tabla)
    print('update_tipoepp', tipo_tabla,detalle, id_parametro)
    datos_json = json.loads(detalle)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        if (tipo_tabla == 'usuario'):
            s = text("select dielab.update_usuario(:a, :b, :c, :d, :e, :f, :g, :h);")
            cur = engine2.connect().execute(s, {"a": datos_json['nombre_usuario'], "b":datos_json['nombre_persona'], "c":datos_json['rut'], "d":datos_json['email'], "e":datos_json['telefono'], "f":datos_json['password'], "g":datos_json['cliente'], "h":id_parametro})
            salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        else:
            s = text("select dielab.update_det_tipo_epp(:a, :b, :c);")
            cur = engine2.connect().execute(s, {"a": tipo_tabla, "b":detalle, "c": id_parametro})
            salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def elimina_param(tipo_tabla, id_tabla):
    #print('tipo_tabla:')
    #print(tipo_tabla)
    #print('id_tabla:')
    #print(id_tabla)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.elimina_param(:a, :b);")
        cur = engine2.connect().execute(s, {"a": tipo_tabla, "b":id_tabla})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def elimina_epp(id_epp, accion):
    #print('id_epp:')
    #print(id_epp)
    #print('accion: ')
    #print(accion)
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.elimina_epp(:a, :b);")
        cur = engine2.connect().execute(s, {"a": id_epp, "b":accion})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def update_codensayo(cod_old, cod_new):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.update_cod_ensayo(:a, :b);")
        cur = engine2.connect().execute(s, {"a": cod_old, "b":cod_new})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        #print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado