from warnings import catch_warnings
from sqlalchemy import create_engine, MetaData, select, Table, and_, text
from modelo.config import conexion


def addcliente(nombre,nombre_corto,responsable,fono,direccion):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    try:
        s = text("select dielab.ingresa_cliente(:a,:b,:c,:d,:e)")
        cur = engine2.connect().execute(s, {"a":nombre, "b": nombre_corto, "c": responsable, "d": fono, "e": direccion})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
    return resultado

def addensayo(cod_ensayo,cliente,sucursal,negocio,temperature,humedad,tecnico,patron,fecha_ej,fecha_in, estado, tipo_ensayo, orden_compra):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.ingresa_enc_ensayo(:a, :b, :c, :d, :e, :f, :g, :h, :i, :l, :m, :n, :p);")
        #print(s)
        print('graba ensayo:')
        print(humedad)
        print('valor de humedad')
        cur = engine2.connect().execute(s, {"a": cod_ensayo, "b":cliente, "c": sucursal, "d": negocio, "e": temperature, "f": humedad, "g": tecnico, "h": patron, "i": fecha_ej, "l": fecha_in, "m": estado, "n":tipo_ensayo, "p":orden_compra})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def adddetensayo(id_batea,detalle):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.ingresa_detalle(:a, :b);")
        #print(s)
        cur = engine2.connect().execute(s, {"a": id_batea, "b":detalle})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def addepp(cod_epp, tipo, cliente,sucursal,negocio, estado, tipo_epp, periodicidad, estado_uso):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.ingresa_epp(:a, :b, :c, :d, :e, :f, :g, :h, :i)")
        cur = engine2.connect().execute(s, {"a": cod_epp, "b": tipo, "c":cliente, "d": sucursal, "e": negocio, "f": estado, "g": tipo_epp, "h":periodicidad, "i":estado_uso})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def emitecert(cod_ensayo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.emite_certificado(:a);")
        cur = engine2.connect().execute(s, {"a": cod_ensayo})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado

def add_tipoepp(tipo_tabla,detalle):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    try:
        engine2.connect()
    except Exception as e:
        resultado = {"error":True, "msg": str(e)}
        return resultado
    try:
        s = text("select dielab.ingresa_det_tipo_epp(:a, :b);")
        #print(s)
        cur = engine2.connect().execute(s, {"a": tipo_tabla, "b":detalle})
        salida = [dict(resultado=row[0]) for row in cur.fetchall()]
        resultado = salida[0]['resultado']
    except Exception as e:
        print(str(e))
        resultado = {"error":True, "msg": str(e)}
    return resultado