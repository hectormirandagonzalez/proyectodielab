from http.client import REQUEST_ENTITY_TOO_LARGE
from sqlalchemy import create_engine, MetaData, select, Table, and_, text
from modelo.config import conexion

def marcar(fec_user, email, nombre, rut, rut_ay, zona, patente, kilometraje, latitud, longitud, tipo):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    engine2.connect()
    #s = text("select autenticacion.in_marca_jornadas(:a,:b,:c,:d,:e,:f,:g,:h,:i,:j,:k)")
    print(fec_user)
    print(email)
    print(nombre)
    print(rut)
    print(rut_ay)
    print(zona)
    print(patente)
    print(kilometraje)
    print(latitud)
    print(longitud)
    print(tipo)
    #s = text("select autenticacion.in_marca_jornadas('" + fec_user + "','" + email
    # + "','" + nombre + "','" + rut + "','" + rut_ay + "','" + zona + "','" + patente + 
    # "'," + str(kilometraje) + "," + str(latitud) + "," + str(longitud) + ",'" + tipo + "')")
    s = text("select autenticacion.in_marca_jornadas(:a,:b,:c,:d,:e,:f,:g,:h,:i,:j,:k)")
    cur = engine2.connect().execute(s, {"a":fec_user, "b": email, "c": nombre, "d": rut, "e": rut_ay,
    "f": zona, "g": patente, "h": kilometraje, "i": latitud, "j": longitud, "k": tipo})
    print(s)
    salida = [dict(resultado=row[0]) for row in cur.fetchall()]
    resultado = salida[0]['resultado']
    return resultado