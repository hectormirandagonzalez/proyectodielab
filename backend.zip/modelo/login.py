from sqlalchemy import create_engine, MetaData, select, Table, and_, text
from modelo.config import conexion


def logear(usuario, clave):
    engine2 = create_engine(conexion).execution_options(autocommit=True)
    metadata2 = MetaData(bind=engine2)
    engine2.connect()
    s = text("select dielab.valida_usuario(:x,:y)")
    cur = engine2.connect().execute(s, {"x":usuario, "y": clave})
    salida = [dict(resultado=row[0]) for row in cur.fetchall()]
    resultado = salida[0]['resultado']
    return resultado