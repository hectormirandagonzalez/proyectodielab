import json
from modelo.config import conexion
from flask import Flask, request, jsonify, send_file, Response
#from werkzeug import FileWrapper
from datetime import datetime, timedelta, timezone
from flask_jwt_extended import create_access_token, get_jwt, get_jwt_identity, \
                                unset_jwt_cookies, jwt_required, JWTManager
from modelo.login import logear
from modelo.marcaje import marcar
from modelo.listados import cliente
from modelo.listados import ensayos
from modelo.listados import cod_ensayo
from modelo.listados import form_ensayo
from modelo.listados import select_param
from modelo.listados import check_epp
from modelo.listados import check_epp_ldb
from modelo.listados import epps
from modelo.listados import getcod_epp
from modelo.listados import get_detalle
from modelo.listados import get_emision
from modelo.listados import get_encabezado_pdf
from modelo.listados import get_detalle_pdf
from modelo.listados import clase_epps
from modelo.listados import clase_ensayo
from modelo.listados import get_tabla_epp
from modelo.listados import get_tabla_pornombre
from modelo.listados import form_in_epps
from modelo.listados import get_tabla_x_nombreId
from modelo.listados import get_encabezado_cliente
from modelo.listados import get_estadistica
from modelo.listados import get_epp_ensayados
from modelo.listados import get_informes_emitidos
from modelo.listados import busca_ensayo
from modelo.agrega import addcliente
from modelo.agrega import addensayo
from modelo.agrega import emitecert
from modelo.agrega import adddetensayo
from modelo.agrega import addepp
from modelo.agrega import add_tipoepp
from modelo.agrega import elimina_param
from modelo.agrega import elimina_epp
from modelo.agrega import update_tipoepp
from modelo.agrega import update_codensayo
from accesorios.genera_pdf import procesa
from accesorios.genera_pdf import procesatest
from accesorios.genera_pdf_lodbus import procesa_lodbus
from accesorios.genera_pdf_jmp import procesa_jmp
from accesorios.genera_xlsx import procesa_stat_xls
from accesorios.genera_xlsx import procesa_historial_xls

app = Flask(__name__)
#app.register_blueprint(login)

# sin_db = True indica que se trabaja sin base de datos, solo pruebas cuandono se puede
# acceder a la base, en condicion normal debe ir en False
sin_db = False

app.config["JWT_SECRET_KEY"] = 'e0bd0675d957b370c1454620f848564b076dfb4afa034bacd281b52ef2bdd81b'
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=24)
jwt = JWTManager(app)
print(conexion)

@app.after_request
def refresh_expiring_jwts(response):
    try:
        exp_timestamp = get_jwt()["exp"]
        now = datetime.now(timezone.utc)
        target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
        if target_timestamp > exp_timestamp:
            access_token = create_access_token(identity=get_jwt_identity())
            data = response.get_json()
            if type(data) is dict:
                data["access_token"] = access_token 
                response.data = json.dumps(data)
        return response
    except (RuntimeError, KeyError):
        # Case where there is not a valid JWT. Just return the original respone
        return response

@app.route('/api/token', methods=['POST'])
def create_token():
    email = request.json.get('email', None)
    password = request.json.get('password', None)
    response = {}
    if sin_db:
        if email != 'demo@demo.cl' or password != '654321':
            return {'msg': 'Error en email o password'}, 401
    else:  
        salida = logear(email,password)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response = salida
    access_token = create_access_token(identity=email)
    #response = {'access_token':access_token}
    response["access_token"] = access_token
    #ir a consultar el menu
    response_body = {}
    if sin_db:
        response_body = {
            "datos":[{"id":"1", "nombre":"guantes", "cod_serie":"GNT", "nombre_menu":"Guantes"}]
        }
    else:
        salida = clase_epps()
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    response["menu_inventario"] = response_body["datos"]
    #ir a consultar el menu ensayo
    response_body = {}
    if sin_db:
        response_body = {
            "datos":[{"id":"1", "nombre":"guantes", "cod_informe":"LAT-GNT" , "cod_serie":"GNT", "nombre_menu":"Guantes"}]
        }
    else:
        salida = clase_ensayo()
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    response["menu_ensayo"] = response_body["datos"]
    print(response)
    return response

@app.route("/api/logout", methods=["POST"])
def logout():
    response = jsonify({"msg": "logout successful"})
    unset_jwt_cookies(response)
    return response

@app.route('/api/profile')
@jwt_required()
def my_profile():
    response_body = {
        "name": "Hector",
        "about" :"Hola mundo flask react"
    }
    return response_body
    
@app.route('/api/valida')
@jwt_required()
def valida_token():
    response_body = {
        "valida":"yes"
    }
    return response_body

@app.route('/api/marcaje', methods=['POST'])
@jwt_required()
def ingresa_marcaje():
    fec_user = request.json.get('fec_user', None)
    #fec_user = '2022-05-10 13:45:00'
    email = request.json.get('email', None)
    #email = 'demo@demo.cl'
    nombre = request.json.get('nombre', None)
    rut = request.json.get('rutma', None)
    rut_ay = request.json.get('rutay', None)
    zona = request.json.get('zonal', None)
    patente = request.json.get('patente', None)
    kilometraje = request.json.get('kilometraje', None)
    #latitud = request.json.get('email', None)
    latitud = -35.334455
    #longitud = request.json.get('email', None)
    longitud = -70.656577
    #tipo = request.json.get('email', None)
    tipo = '04'
    if rut_ay == None:
        rut_ay = ''
    if sin_db:
        response_body = {
            "id_marca": "12001200"
        }
    else:
        salida = marcar(fec_user, email, nombre, rut, rut_ay, zona, patente, kilometraje, latitud, longitud, tipo)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {
            "id_marca": salida["id_marca"]
        }
    return response_body

@app.route('/api/listacliente', methods=['POST'])
def listar_cliente():
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = cliente()
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/listaensayos', methods=['POST'])
def listar_ensayos():
    tipo_ensayo = request.json.get('tipo_ensayo', None)
    serie_ensayo = request.json.get('serie_ensayo', None)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = ensayos(tipo_ensayo, serie_ensayo)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/grabacliente', methods=['POST'])
def graba_cliente():
    nombre = request.json.get('nombre', None)
    nombre_corto = request.json.get('nombre_corto', None)
    responsable = request.json.get('responsable', None)
    fono = request.json.get('fono', None)
    direccion = request.json.get('direccion', None)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = addcliente(nombre, nombre_corto,responsable,fono,direccion)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/grabaensayo', methods=['POST'])
def graba_ensayo():
    cod_ensayo = request.json.get('cod_ensayo', None)
    cliente = request.json.get('cliente', None)
    sucursal = request.json.get('sucursal', None)
    negocio = request.json.get('negocio', None)
    temperatura = request.json.get('temperatura', None)
    humedad = request.json.get('humedad', None)
    tecnico = request.json.get('tecnico', None)
    patron = request.json.get('patron', None)
    fecha_ej = request.json.get('fecha_ejecucion', None)
    fecha_in = request.json.get('fecha_ingreso', None)
    estado = request.json.get('estado', None)
    tipo_ensayo = request.json.get('tipo_ensayo', None)
    orden_compra = request.json.get('orden_compra', None)
    #print('aqui')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = addensayo(cod_ensayo, cliente,sucursal,negocio,temperatura,humedad,tecnico,patron, fecha_ej, fecha_in, estado, tipo_ensayo, orden_compra)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/getcodensayo', methods=['POST'])
def get_cod_ensayo():
    epp = request.json.get('epp', None)
    if sin_db:
        response_body = {
            "datos": "LAT-GNT-99999"
        }
    else:
        salida = cod_ensayo(epp)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
        #print(response_body)
    return response_body

@app.route('/api/selectparam', methods=['POST'])
def selectparam():
    param = request.json.get('param', None)
    if sin_db:
        response_body = {
            "id": "0", "nombre":"quinta"
        }
    else:
        #print('parametro: ' + param)
        salida = select_param(param)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/formensayos', methods=['POST'])
def formEnsayos():
    id_batea = request.json.get('id_batea', None)
    #print(id_batea)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = form_ensayo(id_batea)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/chequea_epp', methods=['POST'])
def checkEpp():
    serie_epp = request.json.get('serie_epp', None)
    cliente = request.json.get('cliente', None)
    negocio = request.json.get('negocio', None)
    sucursal = request.json.get('sucursal', None)
    if sin_db:
        response_body = {
            "datos": "5"
        }
    else:
        if (serie_epp[0:3] == 'LDB'):
            salida = check_epp_ldb(serie_epp, cliente, negocio, sucursal)
        else:
            salida = check_epp(serie_epp, cliente, negocio, sucursal)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/grabadetensayo', methods=['POST'])
def graba_detalleensayo():
    id_batea = request.json.get('id_batea', None)
    detalle = request.json.get('detalle', None)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = adddetensayo(id_batea, detalle)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/getpdf', methods=['POST'])
@jwt_required()
def getPdf():
    #print('procesa(1): ')
    ensayopdf = request.json.get('ensayopdf', None)
    #print('procesa(2): ', ensayopdf)
    verpng = request.json.get('verpng', None)
    
    #print('getPdf: ', ensayopdf)
    #print(ensayopdf)
    salida = get_encabezado_pdf(ensayopdf)
    if salida["error"]:
        #print('1')
        #print(salida["msg"])
        return {'msg': salida["msg"]}, 401
    encabezado = salida["datos"]
    #obtener el detalle
    salida = get_detalle_pdf(ensayopdf)
    if salida["error"]:
        #print('2')
        print(salida["msg"])
        return {'msg': salida["msg"]}, 401
    detalle_pdf = salida["datos"]
    if ensayopdf[4:7] == 'LDB':
        salida = procesa_lodbus(ensayopdf, encabezado, detalle_pdf, verpng)
    elif ensayopdf[4:7] == 'JMP':
        salida = procesa_jmp(ensayopdf, encabezado, detalle_pdf, verpng)
    else:
        #print('procesa(2): ', ensayopdf, verpng)
        salida = procesa(ensayopdf, encabezado, detalle_pdf, verpng)
    esImagen = True

    """
    try:
        json.loads(salida)
    except (RuntimeError, KeyError):
        print('Error al hacer el loads')
        esImagen = True
    """
    """
    if salida["error"]:
        #print('3')
        #print(salida["msg"])
        return {'msg': salida["msg"]}, 401
    """
    if esImagen:
        if verpng:
            #return send_file(salida["msg"], mimetype='image/png')
            return send_file(salida, mimetype='image/png')
        else:
            #return send_file(salida["msg"], mimetype='application/pdf')
            return send_file(salida, mimetype='application/pdf')
    else:
        return {'msg': salida["msg"]}, 401

@app.route('/api/getpng', methods=['POST'])
def getPng():
    valorensayo = request.json.get('valorensayo', None)
    valorelemento = request.json.get('valorelemento', None)
    email = request.json.get('email', None)
    if (email == None):
        #error
        return {'msg': 'El usuario no ha sido especificado'}, 401
    if (email == ''):
        return {'msg': 'El usuario no ha sido especificado'}, 401
    salida = get_encabezado_cliente(valorensayo, valorelemento, email)
    if salida["error"]:
        print('get_encabezado_cliente: ', salida["error"],salida["msg"] )
        return {'msg': salida["msg"]}, 401
    encabezado = salida["datos"]
    print('encabezado: ', encabezado)
    ensayopdf = salida["datos"]["cod_ensayo"]
    #obtener el detalle
    salida = get_detalle_pdf(ensayopdf)
    if salida["error"]:
        return {'msg': salida["msg"]}, 401
    detalle_pdf = salida["datos"]
    if ensayopdf[4:7] == 'LDB':
        salida = procesa_lodbus(ensayopdf, encabezado, detalle_pdf)
    elif ensayopdf[4:7] == 'JMP':
        salida = procesa_jmp(ensayopdf, encabezado, detalle_pdf)
    else:
        salida = procesa(ensayopdf, encabezado, detalle_pdf)
    if salida["error"]:
        return {'msg': salida["msg"]}, 401
    return send_file(salida["msg"], mimetype='image/png')

@app.route('/api/getencabezado_x_cliente', methods=['POST'])
@jwt_required()
def getenc_x_cliente():
    valorensayo = request.json.get('valorensayo', None)
    valorelemento = request.json.get('valorelemento', None)
    email = request.json.get('email', None)
    if (email == None):
        #error
        return {'msg': 'El usuario no ha sido especificado'}, 401
    if (email == ''):
        return {'msg': 'El usuario no ha sido especificado'}, 401
    salida = get_encabezado_cliente(valorensayo, valorelemento, email)
    if salida["error"]:
        print('get_encabezado_cliente: ', salida["error"],salida["msg"] )
        return {'msg': salida["msg"]}, 401
    response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/listaepps', methods=['POST'])
def listar_epps():
    clase_epp = request.json.get('clase_epp', None)
    cod_epp = request.json.get('cod_epp', None)
    #print(clase_epp)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = epps(clase_epp, cod_epp)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/getcodepp', methods=['POST'])
def get_cod_epp():
    epp = request.json.get('epp', None)
    if sin_db:
        response_body = {
            "datos": "GNT-99999"
        }
    else:
        salida = getcod_epp(epp)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
        #print(response_body)
    return response_body

@app.route('/api/grabaepp', methods=['POST'])
def graba_epp():
    cod_epp = request.json.get('cod_epp', None)
    tipo = request.json.get('tipo', None)
    cliente = request.json.get('cliente', None)
    sucursal = request.json.get('sucursal', None)
    negocio = request.json.get('negocio', None)
    estado = request.json.get('estado', None)
    tipo_epp = request.json.get('tipo_epp', None)
    periodicidad = request.json.get('periodicidad', None)
    serie_fabrica = request.json.get('serie_fabrica', None)
    estado_uso = request.json.get('estado_uso', None)
    #print('aqui')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = addepp(cod_epp, tipo, cliente,sucursal,negocio, estado, tipo_epp, periodicidad, estado_uso, serie_fabrica)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/listadetalle', methods=['POST'])
def listar_detalle():
    id_batea = request.json.get('id_batea', None)
    cod_epp = request.json.get('cod_epp', None)
    #print(id_batea)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_detalle(id_batea, cod_epp)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/emitecert', methods=['POST'])
def emite_cert():
    cod_ensayo = request.json.get('cod_ensayo', None)
    #print('aqui')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = emitecert(cod_ensayo)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/getemision', methods=['POST'])
def get_emision():
    cod_ensayo = request.json.get('cod_ensayo', None)
    if sin_db:
        response_body = {
            "datos": "GNT-99999"
        }
    else:
        salida = get_emision(cod_ensayo)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
        #print(response_body)
    return response_body

@app.route('/api/menuinventario', methods=['POST'])
def menu_inventario():
    #print(clase_epp)
    if sin_db:
        response_body = {
            "id":"1", "nombre":"guantes", "cod_serie":"GNT", "tabla_detalle":"tipo_guante", "nombre_menu":"Guantes"
        }
    else:
        salida = clase_epps()
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/menuensayo', methods=['POST'])
def menu_ensayo():
    #print(clase_epp)
    if sin_db:
        response_body = {
            "id":"1", "nombre":"guantes", "cod_informe":"LAT-GNT" , "cod_serie":"GNT", "tabla_detalle":"tipo_guante", "nombre_menu":"Guantes"
        }
    else:
        salida = clase_ensayo()
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/gettablaepp', methods=['POST'])
def get_tablaepp():
    epp = request.json.get('epp', None)
    otro = request.json.get("otro", None)
    #print(epp)
    #print(otro)
    if sin_db:
        response_body = {
            "datos": "GNT-99999"
        }
    else:
        salida = get_tabla_epp(epp)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = salida
        #print(response_body)
    return response_body

@app.route('/api/grabatipoepp', methods=['POST'])
def graba_tipoepp():
    tabla_tipo = request.json.get('tabla_tipo', None)
    datos = request.json.get('datos', None)
    id_parametro = request.json.get('id_parametro', None)
    #print('graba_tipo_epp')
    #print(tabla_tipo)
    #print('graba_tipo_datos')
    #print(datos)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        if (id_parametro == None):
            salida = add_tipoepp(tabla_tipo, datos)
        else:
            salida = update_tipoepp(tabla_tipo, datos, id_parametro)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/gettablapornombre', methods=['POST'])
def get_tabla_por_nombre():
    nombre_tabla = request.json.get('nombre_tabla', None)
    #print(epp)
    if sin_db:
        response_body = {
            "datos": "GNT-99999"
        }
    else:
        salida = get_tabla_pornombre(nombre_tabla)
        if salida == None:
            return {'msg': 'error en get_tabla_pornombre'}, 401
        else:
            if salida["error"]:
                #print(salida["msg"])
                return {'msg': salida["msg"]}, 401
        response_body = salida
        #print(response_body)
    return response_body

@app.route('/api/eliminaparam', methods=['POST'])
def eliminaparam():
    tipo_tabla = request.json.get('tipo_tabla', None)
    id_tabla = request.json.get('id_tabla', None)
    #print('aqui')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        print(tipo_tabla, id_tabla)
        salida = elimina_param(tipo_tabla, id_tabla)
        if salida == None:
            return {'msg': 'Error en funcion eliminaparam'}, 401
        else:
            if salida["error"]:
                #print(salida["msg"])
                return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/eliminaepp', methods=['POST'])
def eliminaepp():
    id_epp = request.json.get('id_epp', None)
    accion = request.json.get('accion', None)
    #print('aqui')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = elimina_epp(id_epp, accion)
        #print('salida:')
        #print(salida["error"])
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body

@app.route('/api/formepps', methods=['POST'])
def form_Epps():
    id_epp = request.json.get('id_epp', None)
    #print(id_batea)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = form_in_epps(id_epp)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/gettablapornombre_id', methods=['POST'])
def  get_tabla_por_nombre_id():
    tabla_tipo = request.json.get('tabla_tipo', None)
    id_parametro = request.json.get('id_parametro', None)

    #print(id_batea)
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_tabla_x_nombreId(tabla_tipo, id_parametro)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/estadistica', methods=['POST'])
@jwt_required()
def getestadistica():
    fecha_ini = request.json.get('fecha_ini', None)
    fecha_fin = request.json.get('fecha_fin', None)
    usuario = get_jwt_identity()
    print('fechas: ', fecha_ini, fecha_fin)
    #response_body = {"usuario": usuario}
    print('usuario')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_estadistica(fecha_ini, fecha_fin, usuario)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/estadistica_xls', methods=['POST'])
@jwt_required()
def getestadistica_xls():
    fecha_ini = request.json.get('fecha_ini', None)
    fecha_fin = request.json.get('fecha_fin', None)
    usuario = get_jwt_identity()
    #print('fechas: ', fecha_ini, fecha_fin)
    #response_body = {"usuario": usuario}
    #print('usuario')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_estadistica(fecha_ini, fecha_fin, usuario)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        archivo = fecha_ini + "_" + fecha_fin
        detalle_estadistica = salida["datos"]
        salida = procesa_stat_xls(detalle_estadistica, archivo)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
    return send_file(salida["msg"], mimetype='application/vnd.ms-excel')

@app.route('/api/historial_xls', methods=['POST'])
@jwt_required()
def historial_xls():
    fecha_ini = request.json.get('fecha_ini', None)
    fecha_fin = request.json.get('fecha_fin', None)
    cliente =  request.json.get('cliente', None)
    elemento = request.json.get('elemento', None)
    usuario = get_jwt_identity()
    #print('fechas: ', fecha_ini, fecha_fin)
    #response_body = {"usuario": usuario}
    #print('usuario')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_epp_ensayados(fecha_ini, fecha_fin, cliente, elemento, usuario)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        archivo = fecha_ini + "_" + fecha_fin
        detalle = salida["datos"]
        salida = procesa_historial_xls(detalle, archivo)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
    return send_file(salida["msg"], mimetype='application/vnd.ms-excel')

@app.route('/api/eppensayados', methods=['POST'])
@jwt_required()
def eppensayados():
    fecha_ini = request.json.get('fecha_ini', None)
    fecha_fin = request.json.get('fecha_fin', None)
    cliente =  request.json.get('cliente', None)
    elemento = request.json.get('elemento', None)
    usuario = get_jwt_identity()
    print('fechas: ', fecha_ini, fecha_fin)
    #response_body = {"usuario": usuario}
    print('usuario')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_epp_ensayados(fecha_ini, fecha_fin, cliente, elemento, usuario)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/informesemitidos', methods=['POST'])
@jwt_required()
def informesemitidos():
    fecha_ini = request.json.get('fecha_ini', None)
    fecha_fin = request.json.get('fecha_fin', None)
    cliente =  request.json.get('cliente', None)
    elemento = request.json.get('elemento', None)
    usuario = get_jwt_identity()
    print('fechas: ', fecha_ini, fecha_fin)
    #response_body = {"usuario": usuario}
    #print('usuario')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = get_informes_emitidos(fecha_ini, fecha_fin, cliente, elemento, usuario)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["datos"]}
    return response_body

@app.route('/api/buscaensayo', methods=['POST'])
def bucasensayo():
    cod_ensayo = request.json.get('cod_ensayo', None)
    if sin_db:
        response_body = {
            "datos": "LAT-GNT-99999"
        }
    else:
        salida = busca_ensayo(cod_ensayo)
        if salida["error"]:
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
        #print(response_body)
    return response_body

@app.route('/api/testpdf', methods=['POST'])
@jwt_required()
def gettestPdf():
    salida = procesatest()
    return send_file(salida, mimetype='application/pdf')

@app.route('/api/actualiza_codensayo', methods=['POST'])
def updatecodensayo():
    cod_old = request.json.get('cod_old', None)
    cod_new = request.json.get('cod_new', None)
    #print('aqui')
    if sin_db:
        response_body = {
            "id_cliente": "0", "nombre":"quinta", "direccion":"av. ventisquero"
        }
    else:
        salida = update_codensayo(cod_old, cod_new)
        if salida["error"]:
            #print(salida["msg"])
            return {'msg': salida["msg"]}, 401
        response_body = {"datos": salida["msg"]}
    return response_body