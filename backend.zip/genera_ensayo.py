from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

w, h = A4
c = canvas.Canvas("ensayo.pdf")
c.drawImage("logo_sm2.jpg", 0, h - 70, 82, 70)
c.setFont("Helvetica-Bold", 11)
c.drawString(250, h - 40, "INFORME DE ENSAYO")
c.setFont("Helvetica", 8)
c.drawString(260, h - 50, "QuintaEnergy Laboratorios.")
c.drawString(210, h - 60, "Avenida Ventisquero 1265, bodega N°4, Renca, Santiago.")
c.setFont("Helvetica-Bold", 11)
c.drawString(255, h - 80, "LAT   -   GNT   -   005")


#############  cuadro de lugar ensayo y datos cliente
c.setFont("Helvetica-Bold", 8)
c.drawString(10, h - 120, "LUGAR DEL ENSAYO Y CONDICIONES AMBIENTALES")
c.drawString(300, h - 120, "ANTECEDENTES DEL CLIENTE")

c.setLineWidth(1)
c.line(10, h - 125, 290, h - 125)
c.line(300, h - 125, 580, h -125)

c.setFont("Helvetica", 8)
c.drawString(10, h - 140, "Lugar")
c.drawString(10, h - 170, "Fecha Ejecución")
c.drawString(10, h - 185, "Realizó")
c.drawString(10, h - 200, "Temperatura (°C) / Humedad (%)")

c.setFont("Helvetica-Bold", 8)
c.drawString(145, h - 140, ":")
c.drawString(145, h - 170, ":")
c.drawString(145, h - 185, ":")
c.drawString(145, h - 200, ":")

c.setFont("Helvetica", 8)
c.drawString(150, h - 140, "Avenida Ventisquero 1265")
c.drawString(150, h - 155, "bodega N°4, Renca, Santiago.")

c.drawString(150, h - 170, "16-05-2022")
c.drawString(150, h - 185, "VMG")
c.drawString(150, h - 200, "18,7 / 38,1")

c.drawString(300, h - 140, "Cliente")
c.drawString(300, h - 155, "Dirección")
c.drawString(300, h - 185, "Ciudad")
c.drawString(300, h - 200, "Fecha Solicitud o Ingreso")

c.setFont("Helvetica-Bold", 8)
c.drawString(435, h - 140, ":")
c.drawString(435, h - 155, ":")
c.drawString(435, h - 185, ":")
c.drawString(435, h - 200, ":")

c.setFont("Helvetica", 8)
c.drawString(440, h - 140, "Eisesa Ltda.")
c.drawString(440, h - 155, "General Bonilla 2286")
c.drawString(440, h - 170, "LT 3, Palomares")
c.drawString(440, h - 185, "Concepción")
c.drawString(440, h - 200, "13-05-2022")

salto = 120
#######3 cuadro de patron y elementos
c.setFont("Helvetica-Bold", 8)
c.drawString(10, h - 120 - salto, "CARACTERÍSTICAS DEL PATRÓN")
c.drawString(300, h - 120 - salto, "ELEMENTOS PROTECCIÓN PERSONAL")

c.setLineWidth(1)
c.line(10, h - 125 - salto, 290, h - 125 - salto)
c.line(300, h - 125 - salto, 580, h -125 - salto)

c.setFont("Helvetica", 8)
c.drawString(10, h - 140 - salto, "Descripción")
c.drawString(10, h - 155 - salto, "Marca")
c.drawString(10, h - 170 - salto, "Modelo")
c.drawString(10, h - 185 - salto, "N° Serie")
c.drawString(10, h - 200 - salto, "Calibración Vigente Hasta")

c.setFont("Helvetica-Bold", 8)
c.drawString(145, h - 140 - salto, ":")
c.drawString(145, h - 155 - salto, ":")
c.drawString(145, h - 170 - salto, ":")
c.drawString(145, h - 185 - salto, ":")
c.drawString(145, h - 200 - salto, ":")

c.setFont("Helvetica", 8)
c.drawString(150, h - 140 - salto, "Hipot AC")
c.drawString(150, h - 155 - salto, "Huazheng")

c.drawString(150, h - 170 - salto, "HZAQ")
c.drawString(150, h - 185 - salto, "HZ181010900104-02")
c.drawString(150, h - 200 - salto, "Noviembre 2022")

c.drawString(300, h - 140 - salto, "Tipo de EPP")
c.drawString(300, h - 155 - salto, "Estado")
c.drawString(300, h - 170 - salto, "Cantidad")

c.setFont("Helvetica-Bold", 8)
c.drawString(435, h - 140 - salto, ":")
c.drawString(435, h - 155 - salto, ":")
c.drawString(435, h - 170 - salto, ":")

c.setFont("Helvetica", 8)
c.drawString(440, h - 140 - salto, "Guantes")
c.drawString(440, h - 155 - salto, "Usado")
c.drawString(440, h - 170 - salto, "12 piezas")

#### tabla resultado
salto = 230
c.setFont("Helvetica-Bold", 8)
c.drawString(260, h - 120 - salto, "TABLA DE RESULTADOS")
c.setLineWidth(1)
c.line(10, h - 125 - salto, 580, h - 125 - salto)

### genera grilla
xlist = [10, 50, 120, 190, 230, 270, 330, 380, 435, 510, 580]
ylist = [h - 135 - salto, h - 165 - salto]
print(ylist)
for i in range(1,13):
    ylist.append(h - 165 - salto - i*15)
c.grid(xlist, ylist)
print(ylist)

## llena grilla
### encabezado
c.setFont("Helvetica-Bold", 8)
c.drawString(15, h - 150 - salto, "ITEM")
c.drawString(55, h - 150 - salto, "Nº UNIDAD")
c.drawString(55, h - 160 - salto, "BAJO PRUEBA")
c.drawString(125, h - 150 - salto, "MARCA")
c.drawString(195, h - 150 - salto, "LARGO")
c.drawString(195, h - 160 - salto, "(mm)")
c.drawString(235, h - 150 - salto, "CLASE")
c.drawString(275, h - 150 - salto, "TENSIÓN DE")
c.drawString(275, h - 160 - salto, "ENSAYO (KV)")
c.drawString(335, h - 150 - salto, "NUM DE")
c.drawString(335, h - 160 - salto, "PARCHES")
c.drawString(385, h - 150 - salto, "I FUGA (mA)")
c.drawString(440, h - 150 - salto, "I MÁX DE FUGA")
c.drawString(440, h - 160 - salto, "PERMITIDA (mA)")
c.drawString(515, h - 150 - salto, "RESULTADO")
#### aquí va el llenado de la tabla


### cuadro conclusiones
c.rect(10, h - 630, 570, 30)
c.setFillColorRGB(0.84, 0.86, 0.87)
c.rect(10, h - 600, 570, 10, fill=True)
c.setFillColorRGB(0, 0, 0)
c.setFont("Helvetica-Bold", 8)
c.drawString(275, h - 599, "CONCLUSIÓN")

c.setFont("Helvetica", 8)
c.drawString(15, h - 610, "Según los resultados obtenenidos en los ensayos dieléctricos, las unidades bajo prueba individualizados que aparecen como aprobados en la tabla anterior,")
c.drawString(15, h - 620, "cumplen con lo indicado en las Normas ASTM D120-14, ASTM F1236-96 y ASTM F496-08.")

### observaciones
c.rect(10, h - 710, 570, 60)
c.setFillColorRGB(0.84, 0.86, 0.87)
c.rect(10, h - 650, 570, 10, fill=True)
c.setFillColorRGB(0, 0, 0)
c.setFont("Helvetica-Bold", 8)
c.drawString(230, h - 648, "OBSERVACIONES Y/O ALCANCES")
c.setFont("Helvetica", 7)
c.drawString(15, h - 657, "Los equipos patrones utilizados para estos ensayos cuentan con su certificado de calibración y/o verificación vigente y trazable al sistema internacional de unidades (SI).")
c.drawString(15, h - 667, "Los resultados expuestos corresponden únicamente al ítem identificado bajo prueba y solo bajo las condiciones mencionadas.")
c.drawString(15, h - 677, "Este informe sólo puede ser difundido íntegro y sin modificaciones ni enmiendas.")
c.drawString(15, h - 687, "Este informe de ensayo no podrá ser reproducido parcialmente sin la aprobación por escrito de QuintaEnergy, el cual declina toda responsabilidad por el uso indebido de")
c.drawString(15, h - 697, "este documento.")
c.drawString(15, h - 707, "Este informe es válido con firma y timbre.")

c.drawImage("firma.jpg", 70, h - 775, 102, 56)
c.drawImage("timbre.jpg", 420, h - 775, 61, 62)
c.setLineWidth(0.5)
c.line(70, h - 780, 200, h - 780)
c.line(380, h - 780, 510, h -780)

c.setFont("Helvetica", 8)
c.drawString(100, h - 790, "José Cortez Lazcano")
c.drawString(90, h - 800, "Responsable Laboratorios")

c.drawString(410, h - 790, "Timbre de Laboratorio")

c.drawString(100, h - 820, "Fecha Emisión")
c.drawString(105, h - 830, "10-06-2022")

c.drawString(420, h - 820, "Fecha Impresión")
c.drawString(425, h - 830, "17-06-2022")

c.drawString(285, h - 830, "Página 1 de 1")

c.showPage()
c.save()