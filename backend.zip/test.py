from sqlalchemy import create_engine, MetaData, select, Table, and_, text
import json

conexion = "postgresql+psycopg2://postgres:cocacola123!!@localhost/backends3"
engine2 = create_engine(conexion).execution_options(autocommit=True)
metadata2 = MetaData(bind=engine2)
engine2.connect()
s = text("select autenticacion.valida_usuario('demo@demo.cl','654321')")
cur = engine2.connect().execute(s)
salida = [dict(resultado=row[0]) for row in cur.fetchall()]
print(salida[0]['resultado'])
#j = json.dumps(salida[0]['resultado'])
#salida_json = json.loads(salida[0]['resutado'])
#print(salida_json)
j = salida[0]['resultado']
print(j["error"])
if j["error"]:
    print('es falso')
else:
    print("es verdadero")